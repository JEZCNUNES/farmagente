/**
 * Seed script: Popula os 48 produtos originais da Rede Farma Gente
 * do arquivo clean_products.json no banco PostgreSQL
 */
const { PrismaClient } = require('@prisma/client');
const fs = require('fs');
const path = require('path');
const bcrypt = require('bcryptjs');

const prisma = new PrismaClient();

async function main() {
  console.log('[SEED] Conectando ao PostgreSQL para semeadura inicial...');

  // 1. Carrega produtos normalizados
  const jsonPath = path.join(__dirname, '..', 'clean_products.json');
  if (!fs.existsSync(jsonPath)) {
    console.error('[SEED] clean_products.json não encontrado!');
    return;
  }

  const raw = fs.readFileSync(jsonPath, 'utf8');
  const products = JSON.parse(raw);

  console.log(`[SEED] Carregados ${products.length} produtos do catálogo.`);

  for (const p of products) {
    try {
      await prisma.product.upsert({
        where: { slug: p.slug },
        create: {
          tinyId: p.tinyId || String(p.id),
          slug: p.slug,
          name: p.name,
          category: p.category || 'Geral',
          brand: p.brand || 'Rede Farma Gente',
          price: parseFloat(p.price) || 49.9,
          oldPrice: p.oldPrice ? parseFloat(p.oldPrice) : null,
          discountPercent: p.discountPercent || 20,
          stock: p.stock || 10,
          freteGratis: p.freteGratis || false,
          badge: p.badge || null,
          rating: p.rating || 4.9,
          reviewsCount: p.reviews || 120,
          image: p.image || '/imgs/br/logo-color.png',
          gallery: p.gallery || [p.image || '/imgs/br/logo-color.png'],
          meliLink: p.meliLink || null,
          description: p.description || p.short || p.name,
          shortDesc: p.short || p.name,
          active: true,
        },
        update: {
          name: p.name,
          price: parseFloat(p.price) || 49.9,
          oldPrice: p.oldPrice ? parseFloat(p.oldPrice) : null,
          stock: p.stock || 10,
          image: p.image || '/imgs/br/logo-color.png',
          active: true,
        },
      });
    } catch (e) {
      console.warn(`[SEED] Aviso no produto ${p.name}:`, e.message);
    }
  }

  // 2. Cria usuário administrador padrão
  const adminPass = await bcrypt.hash('BR@distribuidora2026!', 12);
  await prisma.user.upsert({
    where: { email: 'admin@brdistribuidora.com.br' },
    create: {
      name: 'Administrador Rede Farma Gente',
      email: 'admin@brdistribuidora.com.br',
      passwordHash: adminPass,
      role: 'ADMIN',
      phone: '19992893859',
    },
    update: {},
  }).catch((e) => console.warn('[SEED] Admin note:', e.message));

  console.log('✅ [SEED] Catálogo técnico da Rede Farma Gente populado com sucesso no PostgreSQL!');
}

main()
  .catch((e) => {
    console.error('[SEED] Erro fatal:', e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
