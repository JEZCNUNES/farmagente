/**
 * Script de Sincronização Tiny ERP -> PostgreSQL
 * Pode ser executado via terminal (npm run sync:tiny) ou via cron job
 */
require('dotenv').config();
const { PrismaClient } = require('@prisma/client');
const prisma = new PrismaClient();

const delay = (ms) => new Promise((resolve) => setTimeout(resolve, ms));
const TINY_API_BASE = 'https://api.tiny.com.br/api2';

function slugify(text) {
  return text
    .toString()
    .toLowerCase()
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/(^-|-$)+/g, '')
    .slice(0, 80);
}

function categorize(title = '') {
  const t = title.toLowerCase();
  if (t.includes('cabo de rede') || t.includes('cat5') || t.includes('cat6') || t.includes('cat6a') || t.includes('sohoplus') || t.includes('gigalan')) {
    return 'Cabeamento Estruturado';
  }
  if (t.includes('rj45') || t.includes('keystone') || t.includes('conector') || t.includes('plug')) {
    return 'Conectorização & Conexões';
  }
  if (t.includes('patch panel') || t.includes('patch cord') || t.includes('guia de cabo')) {
    return 'Patch Panels & Racks';
  }
  if (t.includes('nobreak') || t.includes('ups') || t.includes('bateria') || t.includes('senoidal')) {
    return 'Nobreaks & Energia Crítica';
  }
  if (t.includes('eletrocalha') || t.includes('eletroduto') || t.includes('condulete') || t.includes('canaleta') || t.includes('uniduto')) {
    return 'Infraestrutura Seca';
  }
  if (t.includes('caixa de comando') || t.includes('quadro de comando') || t.includes('painel') || t.includes('ip65')) {
    return 'Caixas de Comando & Painéis';
  }
  if (t.includes('rotulador') || t.includes('etiqueta') || t.includes('fita tze') || t.includes('brother')) {
    return 'Rotuladores & Identificação';
  }
  if (t.includes('câmera') || t.includes('camera') || t.includes('dvr') || t.includes('nvr') || t.includes('vms') || t.includes('digifort') || t.includes('seventh') || t.includes('cftv')) {
    return 'CFTV & Segurança Eletrônica';
  }
  if (t.includes('catraca') || t.includes('facial') || t.includes('biometria') || t.includes('eletroímã') || t.includes('eletroima') || t.includes('barreira') || t.includes('cancela')) {
    return 'Controle de Acesso Corporativo';
  }
  if (t.includes('fibra') || t.includes('óptica') || t.includes('optica') || t.includes('dio') || t.includes('pigtail') || t.includes('cordão') || t.includes('cordao') || t.includes('acoplador') || t.includes('tubete')) {
    return 'Fibra Óptica & FTTH';
  }
  if (t.includes('dps') || t.includes('protetor de surto') || t.includes('clamper') || t.includes('protetor de rede')) {
    return 'Protetores de Energia & Rede';
  }
  return 'Cabeamento Estruturado';
}

function detectBrand(title = '') {
  const t = title.toLowerCase();
  if (t.includes('furukawa')) return 'Furukawa';
  if (t.includes('commscope') || t.includes('systimax')) return 'CommScope';
  if (t.includes('legrand')) return 'Legrand';
  if (t.includes('siemon')) return 'Siemon';
  if (t.includes('megatron')) return 'Megatron';
  if (t.includes('2flex')) return '2Flex';
  if (t.includes('mpt')) return 'MPT';
  if (t.includes('sms')) return 'SMS';
  if (t.includes('vertiv')) return 'Vertiv';
  if (t.includes('eaton')) return 'Eaton';
  if (t.includes('hikvision')) return 'Hikvision';
  if (t.includes('intelbras')) return 'Intelbras';
  if (t.includes('uniview')) return 'Uniview';
  if (t.includes('motorola')) return 'Motorola';
  if (t.includes('mdx')) return 'MDX';
  if (t.includes('dell')) return 'Dell';
  if (t.includes('zkteco')) return 'ZKTeco';
  if (t.includes('control id') || t.includes('controlid')) return 'Control iD';
  if (t.includes('fibracem')) return 'Fibracem';
  if (t.includes('clamper')) return 'Clamper';
  if (t.includes('brother')) return 'Brother';
  if (t.includes('digifort')) return 'Digifort';
  return 'Rede Farma Gente';
}

async function runSync() {
  const token = process.env.TINY_API_TOKEN;
  if (!token) {
    console.error('❌ [TINY SYNC] TINY_API_TOKEN não encontrado nas variáveis de ambiente.');
    process.exit(1);
  }

  console.log('🔄 [TINY SYNC] Conectando à API do Tiny ERP...');
  const startTime = new Date();

  try {
    const res = await fetch(`${TINY_API_BASE}/produtos.pesquisa.php?token=${token}&formato=json&pagina=1`);
    const data = await res.json();

    if (data?.retorno?.status === 'ERRO') {
      throw new Error(data?.retorno?.erros?.[0]?.erro || 'Erro na API do Tiny');
    }

    const items = data?.retorno?.produtos || [];
    console.log(`📦 [TINY SYNC] ${items.length} produtos encontrados.`);

    let count = 0;
    for (const wrapper of items) {
      const p = wrapper.produto;
      if (!p || !p.id) continue;

      // Respeita limite técnico de 30 req/min
      await delay(2000);

      // Consulta estoque do item
      let stock = 0;
      try {
        const stockRes = await fetch(`${TINY_API_BASE}/produto.obter.estoque.php?token=${token}&id=${p.id}&formato=json`);
        const stockData = await stockRes.json();
        if (stockData?.retorno?.produto?.saldo !== undefined) {
          stock = parseFloat(stockData.retorno.produto.saldo);
        }
      } catch (err) {
        // mantém 0
      }

      const price = parseFloat(p.preco) || 49.9;
      const oldPrice = price * 1.25;
      const slug = `${slugify(p.nome)}-${p.id}`;

      await prisma.product.upsert({
        where: { tinyId: String(p.id) },
        create: {
          tinyId: String(p.id),
          sku: p.codigo || null,
          gtin: p.gtin || null,
          name: p.nome,
          slug,
          price,
          oldPrice,
          discountPercent: 20,
          stock: Math.max(stock, 0),
          category: categorize(p.nome),
          brand: detectBrand(p.nome),
          freteGratis: price >= 199,
          image: '/imgs/canaltop.png',
          gallery: ['/imgs/canaltop.png'],
          description: `${p.nome}. Produto original faturado com nota fiscal e garantia oficial pela Canal Distribuidora. Pronta entrega.`,
          shortDesc: p.nome,
          active: p.situacao === 'A',
        },
        update: {
          name: p.nome,
          price,
          stock: Math.max(stock, 0),
          freteGratis: price >= 199,
          active: p.situacao === 'A',
        },
      });

      count++;
      console.log(`  [${count}/${items.length}] Sincronizado: ${p.nome.slice(0, 45)}... (Estoque: ${stock})`);
    }

    console.log(`✅ [TINY SYNC] Sincronização concluída com sucesso em ${((Date.now() - startTime) / 1000).toFixed(1)}s!`);
  } catch (error) {
    console.error('❌ [TINY SYNC] Falha na sincronização:', error.message);
  } finally {
    await prisma.$disconnect();
  }
}

runSync();
