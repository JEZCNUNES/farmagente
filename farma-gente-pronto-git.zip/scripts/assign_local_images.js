const fs = require('fs');
const path = require('path');

const filePaths = [
  path.join(__dirname, '..', 'clean_products.json'),
  path.join(__dirname, '..', 'public', 'clean_products.json')
];

function getImageForProduct(p) {
  const cat = (p.category || '').toLowerCase();
  const name = (p.name || '').toLowerCase();

  if (cat.includes('cabeamento') || name.includes('cabo de rede') || name.includes('sohoplus') || name.includes('cat6') || name.includes('cat5e') || name.includes('cat6a')) {
    return '/imgs/products/cabo-furukawa-cat6.jpg';
  }
  if (cat.includes('conector') || name.includes('keystone') || name.includes('patch cord') || name.includes('patch panel') || name.includes('rj45')) {
    return '/imgs/products/conector-keystone-cat6.jpg';
  }
  if (cat.includes('nobreak') || name.includes('nobreak') || name.includes('ups') || name.includes('bateria') || name.includes('vertiv') || name.includes('sms')) {
    return '/imgs/products/nobreak-vertiv-ups.jpg';
  }
  if (cat.includes('cftv') || cat.includes('segurança') || name.includes('câmera') || name.includes('hikvision') || name.includes('speed dome') || name.includes('nvr') || name.includes('dvr')) {
    return '/imgs/products/camera-hikvision-4k.jpg';
  }
  if (cat.includes('fibra') || name.includes('dio') || name.includes('óptico') || name.includes('ftth') || name.includes('pigtail') || name.includes('cordão óptico')) {
    return '/imgs/products/dio-fibra-optica.jpg';
  }
  if (cat.includes('proteção') || cat.includes('dps') || name.includes('clamper') || name.includes('surto') || name.includes('dps')) {
    return '/imgs/products/clamper-dps-vcl.jpg';
  }
  if (cat.includes('acesso') || name.includes('facial') || name.includes('catraca') || name.includes('idface') || name.includes('zkteco') || name.includes('fechadura')) {
    return '/imgs/products/control-id-facial.jpg';
  }

  return '/imgs/products/cabo-furukawa-cat6.jpg';
}

filePaths.forEach((fp) => {
  if (fs.existsSync(fp)) {
    const raw = fs.readFileSync(fp, 'utf8');
    const products = JSON.parse(raw);
    const updated = products.map((p) => {
      const img = getImageForProduct(p);
      return {
        ...p,
        image: img,
        gallery: [img]
      };
    });
    fs.writeFileSync(fp, JSON.stringify(updated, null, 2), 'utf8');
    console.log(`Updated ${updated.length} products in ${fp}`);
  }
});
