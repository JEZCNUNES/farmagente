/**
 * Cron Worker autônomo para sincronização de estoque a cada 15 minutos
 * Regra do PDF: Um job a cada 15 min copia produtos e estoque para o banco do site
 */
require('dotenv').config();
const cron = require('node-cron');
const { exec } = require('child_process');
const path = require('path');

console.log('🕒 [WORKER] Iniciando agendador de sincronização Tiny ERP (intervalo: 15 minutos)...');

const syncScript = path.join(__dirname, 'sync-tiny.js');

function triggerSync() {
  console.log(`⏰ [WORKER ${new Date().toLocaleTimeString('pt-BR')}] Disparando job de sincronização com Tiny ERP...`);
  exec(`node "${syncScript}"`, (err, stdout, stderr) => {
    if (err) {
      console.error('❌ [WORKER] Erro na execução da sincronização:', err.message);
      return;
    }
    if (stdout) console.log(stdout);
    if (stderr) console.warn(stderr);
    console.log(`✅ [WORKER ${new Date().toLocaleTimeString('pt-BR')}] Ciclo concluído. Próxima sincronização em 15 minutos.`);
  });
}

// Executa uma vez na inicialização
triggerSync();

// Executa a cada 15 minutos
cron.schedule('*/15 * * * *', () => {
  triggerSync();
});
