# Rede Farma Gente - Drogaria Itajaí 💊✨

Loja virtual moderna e completa para a **Rede Farma Gente - Drogaria Itajaí**, inspirada na experiência de usuário da **Drogasil**, com arquitetura backend integrada (Next.js 14, PostgreSQL/Prisma, Asaas para PIX dinâmico, Melhor Envio e Tiny ERP).

---

## 🎨 Identidade Visual & Design System
- **Cores Oficiais da Marca:**
  - **Magenta / Rosa:** `#DA1C82`
  - **Turquesa / Teal:** `#009B9D`
  - **Fundo:** Branco Puro `#FFFFFF` & Cinza Suave `#F8FAFC`
  - **Texto & Detalhes:** `#0F172A` & `#64748B`
- **Mascote Sol:**
  - Assistente e Farmacêutica Virtual da Farma Gente
  - Widget flutuante no canto inferior direito ("Oi! Eu sou a Sol! 👋")
  - Balão de boas-vindas com micro-animação
  - Chat inteligente com busca de medicamentos no catálogo e redirecionamento para WhatsApp oficial

---

## 🚀 Estrutura de Arquivos

```
farma-gente/
├── components/          # Componentes React (Header, Footer, CartDrawer, FarmaBot)
├── css/                 # Estilos globais (styles.css - Design System Drogasil)
├── imgs/                # Imagens otimizadas (PNG e WebP)
│   ├── banners/         # Banners promocionais e institucionais com a mascote Sol
│   ├── categories/      # Banners visuais de categorias ("Cuidados que você merece")
│   ├── logo/            # Logotipos transparentes, horizontais e favicons
│   ├── mascote/         # Sol (avatares redondos, acenando e com cesta de remédios)
│   └── products/        # 20 produtos farmacêuticos com bulas e embalagens
├── js/                  # Módulos JavaScript (products.js, cart.js, farma-bot.js)
├── lib/                 # Integrações Backend (Asaas, Melhor Envio, Tiny ERP, Prisma)
├── pages/               # Rotas Next.js (index, loja, produto/[slug], carrinho, checkout, etc.)
│   └── api/             # Endpoints REST (products, shipping, checkout, auth, webhooks)
├── prisma/              # Schema do banco de dados PostgreSQL
├── public/              # Arquivos públicos estáticos espelhados
├── scripts/             # Scripts de seed e sincronização Tiny ERP
├── clean_products.json  # Catálogo completo com 20 medicamentos e dermocosméticos
├── package.json         # Dependências do projeto
├── .env.example         # Variáveis de ambiente de exemplo
└── index.html           # Versão estática completa pronta para execução direta
```

---

## ⚡ Como Rodar o Projeto

### Opção 1: Next.js Fullstack (Recomendado)
```bash
# 1. Instalar dependências (já linkadas na máquina local)
npm install

# 2. Configurar variáveis de ambiente
cp .env.example .env

# 3. Gerar cliente do Prisma
npx prisma generate

# 4. Iniciar servidor de desenvolvimento
npm run dev
# Acesse http://localhost:3000
```

### Opção 2: Servidor Estático / Preview Direto
Abra o arquivo `index.html` em qualquer navegador ou suba para qualquer hospedagem estática (Vercel, Netlify, Cloudflare Pages, GitHub Pages).

---

## 📞 Contatos & Informações
- **Central:** (47) 3348-1020
- **WhatsApp Oficial:** (47) 99988-7766
- **Farmacêutica Técnica:** Dra. Solange S. Silveira (Sol) - CRF/SC nº 12.845
- **Endereço:** Av. Sete de Setembro, 1200 - Centro, Itajaí - SC
