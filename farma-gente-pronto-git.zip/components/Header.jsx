import React, { useState, useEffect } from 'react';
import Link from 'next/link';
import { useRouter } from 'next/router';

export default function Header({ onOpenCart }) {
  const router = useRouter();
  const [cartCount, setCartCount] = useState(0);
  const [cartTotal, setCartTotal] = useState(0);
  const [searchQuery, setSearchQuery] = useState('');
  const [savedCep, setSavedCep] = useState('');

  const syncCounts = () => {
    try {
      const cart = JSON.parse(localStorage.getItem('cm.cart') || '[]');
      const count = cart.reduce((acc, it) => acc + (it.qty || 1), 0);
      const total = cart.reduce((acc, it) => acc + (it.price * (it.qty || 1)), 0);
      setCartCount(count);
      setCartTotal(total);

      const cep = localStorage.getItem('cm.cep') || '';
      if (cep) setSavedCep(cep);
    } catch (e) {}
  };

  useEffect(() => {
    syncCounts();
    window.addEventListener('storage', syncCounts);
    const interval = setInterval(syncCounts, 1000);
    return () => {
      window.removeEventListener('storage', syncCounts);
      clearInterval(interval);
    };
  }, []);

  const handleSearch = (e) => {
    e.preventDefault();
    if (searchQuery.trim()) {
      router.push(`/loja?q=${encodeURIComponent(searchQuery.trim())}`);
    }
  };

  return (
    <>
      <div className="top-bar">
        <div className="container top-bar-content">
          <span>🚚 <strong>Frete Grátis</strong> acima de R$ 149,00</span>
          <span className="top-bar-badge">⚡ Entrega Expressa</span>
          <span>Receba em até 1h em Itajaí e Região!</span>
          <Link href="/suporte" style={{ marginLeft: 'auto', textDecoration: 'underline', fontSize: 12 }}>
            Televendas: (47) 3348-1020
          </Link>
        </div>
      </div>

      <header className="header-main">
        <div className="container">
          <div className="header-row">
            <Link href="/" className="header-logo">
              <img src="/imgs/logo/logo-farma.png" alt="Rede Farma Gente - Drogaria Itajaí" />
            </Link>

            <div className="header-search">
              <form onSubmit={handleSearch}>
                <div className="search-box">
                  <input
                    type="text"
                    className="search-input"
                    placeholder="Buscar por medicamentos, dermocosméticos, marcas..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                  />
                  <button type="submit" className="search-btn">
                    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5">
                      <circle cx="11" cy="11" r="8"></circle>
                      <line x1="21" y1="21" x2="16.65" y2="16.65"></line>
                    </svg>
                  </button>
                </div>
              </form>
            </div>

            <div className="header-actions">
              <button
                className="action-btn action-btn-prescription"
                onClick={() => {
                  if (typeof window !== 'undefined' && window.openPrescriptionModal) {
                    window.openPrescriptionModal();
                  } else {
                    window.open('https://wa.me/5547999887766?text=' + encodeURIComponent('Olá! Gostaria de enviar uma receita médica para a Farma Gente.'), '_blank');
                  }
                }}
              >
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                  <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"></path>
                  <polyline points="14 2 14 8 20 8"></polyline>
                  <line x1="12" y1="18" x2="12" y2="12"></line>
                  <line x1="9" y1="15" x2="15" y2="15"></line>
                </svg>
                <span>Enviar Receita</span>
              </button>

              <Link href="/rastrear" className="action-btn">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                  <rect x="1" y="3" width="15" height="13"></rect>
                  <polygon points="16 8 20 8 23 11 23 16 16 16 8"></polygon>
                  <circle cx="5.5" cy="18.5" r="2.5"></circle>
                  <circle cx="18.5" cy="18.5" r="2.5"></circle>
                </svg>
                <span>Rastrear</span>
              </Link>

              <button className="cart-btn-pill" onClick={onOpenCart}>
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                  <circle cx="9" cy="21" r="1"></circle>
                  <circle cx="20" cy="21" r="1"></circle>
                  <path d="M1 1h4l2.68 13.39a2 2 0 0 0 2 1.61h9.72a2 2 0 0 0 2-1.61L23 6H6"></path>
                </svg>
                <span className="cart-btn-price">
                  {new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(cartTotal)}
                </span>
                <span className="cart-badge">{cartCount}</span>
              </button>
            </div>
          </div>
        </div>

        <div className="header-subnav">
          <div className="container">
            <div className="subnav-row">
              <div className="cep-selector">
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5">
                  <path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"></path>
                  <circle cx="12" cy="10" r="3"></circle>
                </svg>
                <span>{savedCep ? `Entregar em: ${savedCep}` : 'Entregar em: Itajaí - SC'}</span>
              </div>

              <div className="subnav-links">
                <Link href="/loja" className="subnav-link">Catálogo Completo</Link>
                <Link href="/loja?cat=Medicamentos" className="subnav-link">Medicamentos</Link>
                <Link href="/loja?cat=Dermocosméticos" className="subnav-link">Dermocosméticos</Link>
                <Link href="/loja?cat=Vitaminas" className="subnav-link">Vitaminas</Link>
                <Link href="/loja?cat=Mamãe & Bebê" className="subnav-link">Mamãe & Bebê</Link>
                <Link href="/loja?cat=Linha Profissional" className="subnav-link">Linha Profissional</Link>
                <Link href="/suporte" className="subnav-link">Atendimento</Link>
              </div>

              <Link href="/loja?ofertas=1" className="clube-btn">
                ✨ Clube Farma Gente
              </Link>
            </div>
          </div>
        </div>
      </header>
    </>
  );
}
