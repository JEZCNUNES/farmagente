import React, { useState } from 'react';
import Link from 'next/link';

export default function BRBot() {
  const [isOpen, setIsOpen] = useState(false);
  const [meters, setMeters] = useState('');
  const [cableType, setCableType] = useState('cat6');
  const [calcResult, setCalcResult] = useState(null);

  const handleCalc = (e) => {
    e.preventDefault();
    const m = parseFloat(meters);
    if (!m || m <= 0) return;
    const boxMeters = 305;
    const boxes = Math.ceil(m / boxMeters);
    const waste = Math.round(boxes * boxMeters - m);
    setCalcResult({
      meters: m,
      boxes,
      waste,
      cableName: cableType === 'cat6' ? 'CAT6 UTP (250MHz)' : cableType === 'cat6a' ? 'CAT6A Blindado (500MHz)' : 'CAT5e 100% Cobre',
    });
  };

  return (
    <>
      {/* Floating Trigger Button */}
      <div
        onClick={() => setIsOpen(!isOpen)}
        title="Assistente Técnico da BR Distribuidora"
        style={{
          position: 'fixed',
          bottom: '24px',
          right: '24px',
          background: 'var(--br-blue)',
          color: '#FFFFFF',
          borderRadius: '50px',
          padding: '8px 18px 8px 10px',
          display: 'flex',
          alignItems: 'center',
          gap: '10px',
          cursor: 'pointer',
          boxShadow: '0 4px 16px rgba(0, 67, 166, 0.4)',
          zIndex: 900,
          border: '2px solid #FFFFFF',
          transition: 'transform 0.2s, background 0.2s'
        }}
        onMouseEnter={(e) => { e.currentTarget.style.transform = 'scale(1.04)'; e.currentTarget.style.background = 'var(--br-blue-dark)'; }}
        onMouseLeave={(e) => { e.currentTarget.style.transform = 'scale(1)'; e.currentTarget.style.background = 'var(--br-blue)'; }}
      >
        <div style={{ width: '38px', height: '38px', borderRadius: '50%', background: '#FFFFFF', display: 'flex', alignItems: 'center', justifyContent: 'center', overflow: 'hidden' }}>
          <img
            src="/imgs/br/mascote-tablet-tight.png"
            alt="Mascote BR"
            style={{ width: '34px', height: '34px', objectFit: 'contain' }}
          />
        </div>
        <div style={{ lineHeight: 1.2 }}>
          <strong style={{ display: 'block', fontSize: '12px' }}>Suporte Técnico</strong>
          <span style={{ fontSize: '10.5px', color: '#B9D5F0', display: 'flex', alignItems: 'center', gap: '4px' }}>
            <span style={{ width: '6px', height: '6px', borderRadius: '50%', background: '#10B981' }}></span>
            Online agora
          </span>
        </div>
      </div>

      {/* Interactive Modal */}
      {isOpen && (
        <div
          style={{
            position: 'fixed',
            bottom: '84px',
            right: '24px',
            width: '360px',
            maxWidth: 'calc(100vw - 32px)',
            background: '#FFFFFF',
            border: '1px solid var(--border-light)',
            borderRadius: '12px',
            boxShadow: '0 16px 40px rgba(0, 0, 0, 0.2)',
            zIndex: 999,
            overflow: 'hidden'
          }}
        >
          {/* Header */}
          <div
            style={{
              background: 'var(--br-blue)',
              padding: '14px 18px',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'space-between',
              color: 'white'
            }}
          >
            <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
              <img
                src="/imgs/br/mascote-thumbsup-tight.png"
                alt="Mascote BR"
                style={{ width: '36px', height: '36px', objectFit: 'contain', background: 'rgba(255,255,255,0.15)', borderRadius: '50%', padding: '2px' }}
              />
              <div>
                <strong style={{ display: 'block', fontSize: '13.5px' }}>Assistente de Projetos</strong>
                <span style={{ fontSize: '11px', color: '#B9D5F0' }}>BR Distribuidora Oficial</span>
              </div>
            </div>
            <button
              onClick={() => setIsOpen(false)}
              style={{ background: 'transparent', border: 'none', color: 'white', fontSize: '18px', cursor: 'pointer' }}
            >
              ✕
            </button>
          </div>

          {/* Body */}
          <div style={{ padding: '16px', maxHeight: '420px', overflowY: 'auto' }}>
            <div
              style={{
                background: '#F8F9FA',
                border: '1px solid var(--border-subtle)',
                borderRadius: '6px',
                padding: '12px',
                marginBottom: '14px',
                fontSize: '12.5px',
                color: 'var(--text-dark)',
                lineHeight: 1.45
              }}
            >
              Olá! Sou o especialista de infraestrutura da <strong>BR Distribuidora</strong>. Como podemos agilizar a cotação do seu projeto hoje?
            </div>

            {/* Quick Actions */}
            <div style={{ display: 'flex', flexDirection: 'column', gap: '8px', marginBottom: '16px' }}>
              <a
                href="https://wa.me/5519992893859?text=Ol%C3%A1!%20Gostaria%20de%20uma%20cota%C3%A7%C3%A3o%20especial%20para%20minha%20empresa."
                target="_blank"
                rel="noreferrer"
                style={{
                  background: '#1F9050',
                  color: '#FFFFFF',
                  padding: '10px 14px',
                  borderRadius: '6px',
                  fontSize: '12px',
                  fontWeight: 700,
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'space-between'
                }}
              >
                <span>Falar com Engenheiro no WhatsApp</span>
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5">
                  <polyline points="9 18 15 12 9 6"></polyline>
                </svg>
              </a>

              <Link
                href="/rastrear"
                onClick={() => setIsOpen(false)}
                style={{
                  background: '#F1F5F9',
                  border: '1px solid var(--border-light)',
                  color: 'var(--text-dark)',
                  padding: '10px 14px',
                  borderRadius: '6px',
                  fontSize: '12px',
                  fontWeight: 700,
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'space-between'
                }}
              >
                <span>Rastrear Minha Encomenda</span>
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5">
                  <polyline points="9 18 15 12 9 6"></polyline>
                </svg>
              </Link>
            </div>

            {/* Cable Calculator Feature */}
            <div
              style={{
                background: '#F8F9FA',
                border: '1px solid var(--border-light)',
                borderRadius: '8px',
                padding: '14px'
              }}
            >
              <div style={{ display: 'flex', alignItems: 'center', gap: '6px', marginBottom: '10px' }}>
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="var(--kabum-blue)" strokeWidth="2">
                  <rect x="4" y="4" width="16" height="16" rx="2"></rect>
                  <line x1="9" y1="9" x2="9" y2="15"></line>
                  <line x1="12" y1="9" x2="12" y2="15"></line>
                  <line x1="15" y1="9" x2="15" y2="15"></line>
                </svg>
                <strong style={{ fontSize: '12.5px', color: 'var(--text-black)' }}>
                  Calculadora de Caixas de Cabo
                </strong>
              </div>

              <form onSubmit={handleCalc}>
                <div style={{ marginBottom: '8px' }}>
                  <label style={{ fontSize: '11px', color: 'var(--text-gray)', display: 'block', marginBottom: '4px' }}>
                    Metragem total necessária (metros):
                  </label>
                  <input
                    type="number"
                    placeholder="Ex: 1250"
                    value={meters}
                    onChange={(e) => setMeters(e.target.value)}
                    style={{
                      width: '100%',
                      padding: '8px 10px',
                      background: '#FFFFFF',
                      border: '1px solid var(--border-light)',
                      borderRadius: '4px',
                      fontSize: '13px',
                      color: 'var(--text-dark)'
                    }}
                    required
                  />
                </div>

                <div style={{ marginBottom: '12px' }}>
                  <label style={{ fontSize: '11px', color: 'var(--text-gray)', display: 'block', marginBottom: '4px' }}>
                    Padrão do cabo de rede:
                  </label>
                  <select
                    value={cableType}
                    onChange={(e) => setCableType(e.target.value)}
                    style={{
                      width: '100%',
                      padding: '8px 10px',
                      background: '#FFFFFF',
                      border: '1px solid var(--border-light)',
                      borderRadius: '4px',
                      fontSize: '12px',
                      color: 'var(--text-dark)'
                    }}
                  >
                    <option value="cat6">CAT6 UTP (250MHz - Furukawa / CommScope)</option>
                    <option value="cat6a">CAT6A Blindado (500MHz 10Gbps)</option>
                    <option value="cat5e">CAT5e 100% Cobre (100MHz)</option>
                  </select>
                </div>

                <button
                  type="submit"
                  style={{
                    width: '100%',
                    background: 'var(--kabum-orange)',
                    color: '#FFFFFF',
                    border: 'none',
                    borderRadius: '4px',
                    padding: '9px',
                    fontSize: '12px',
                    fontWeight: 800,
                    cursor: 'pointer'
                  }}
                >
                  Calcular Caixas (305m)
                </button>
              </form>

              {calcResult && (
                <div
                  style={{
                    marginTop: '12px',
                    padding: '10px',
                    background: '#EBF4FC',
                    border: '1px solid var(--kabum-blue)',
                    borderRadius: '6px',
                    fontSize: '12px',
                    color: 'var(--text-dark)'
                  }}
                >
                  <div style={{ fontWeight: 800, color: 'var(--kabum-blue)', marginBottom: '4px' }}>
                    Resultado para {calcResult.cableName}:
                  </div>
                  <div>Necessárias: <strong>{calcResult.boxes} caixas</strong> de 305m</div>
                  <div style={{ fontSize: '11px', color: 'var(--text-gray)', marginTop: '2px' }}>
                    Sobra estimada de segurança: {calcResult.waste}m
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      )}
    </>
  );
}
