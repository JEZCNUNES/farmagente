import React, { useState, useEffect, useRef } from 'react';

export default function FarmaBot() {
  const [isOpen, setIsOpen] = useState(false);
  const [bubbleVisible, setBubbleVisible] = useState(true);
  const [messages, setMessages] = useState([
    {
      sender: 'bot',
      text: 'Olá! Bem-vindo(a) à Rede Farma Gente - Drogaria Itajaí! 💊 Como posso te ajudar hoje? Posso buscar remédios ou te ajudar com envio de receita médica.'
    }
  ]);
  const [inputVal, setInputVal] = useState('');
  const msgEndRef = useRef(null);

  useEffect(() => {
    const t = setTimeout(() => setBubbleVisible(true), 2500);
    return () => clearTimeout(t);
  }, []);

  useEffect(() => {
    msgEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, isOpen]);

  const sendMessage = (text) => {
    if (!text.trim()) return;
    const userMsg = { sender: 'user', text };
    setMessages((prev) => [...prev, userMsg]);
    setInputVal('');

    setTimeout(() => {
      const q = text.toLowerCase();
      if (q.includes('receita') || q.includes('crm') || q.includes('médico')) {
        setMessages((prev) => [
          ...prev,
          {
            sender: 'bot',
            text: '📋 Você pode enviar sua receita médica pelo WhatsApp para nossos farmacêuticos conferirem a dosagem e separarem seu pedido com agilidade!',
            link: 'https://wa.me/5547999887766?text=' + encodeURIComponent('Olá Sol! Gostaria de enviar uma receita médica para orçamento na Drogaria Itajaí.')
          }
        ]);
      } else if (q.includes('frete') || q.includes('entrega')) {
        setMessages((prev) => [
          ...prev,
          {
            sender: 'bot',
            text: '🚚 Entregamos em até 1 hora em Itajaí e Região! E nas compras acima de R$ 149,00 o frete é GRÁTIS para todo o Brasil via Melhor Envio / Correios.'
          }
        ]);
      } else if (q.includes('whatsapp') || q.includes('atendente') || q.includes('falar')) {
        setMessages((prev) => [
          ...prev,
          {
            sender: 'bot',
            text: '📱 Fale agora com nossa equipe no WhatsApp oficial: (47) 99988-7766!',
            link: 'https://wa.me/5547999887766'
          }
        ]);
      } else {
        setMessages((prev) => [
          ...prev,
          {
            sender: 'bot',
            text: `Entendi sua dúvida sobre "${text}". Se desejar uma orientação farmacêutica personalizada, clique abaixo para falar no WhatsApp:`,
            link: 'https://wa.me/5547999887766?text=' + encodeURIComponent(`Olá Sol! Tenho uma dúvida sobre: ${text}`)
          }
        ]);
      }
    }, 450);
  };

  return (
    <div style={{ position: 'fixed', bottom: 24, right: 24, zIndex: 180 }}>
      {/* Speech bubble */}
      {!isOpen && bubbleVisible && (
        <div
          onClick={() => setIsOpen(true)}
          style={{
            position: 'absolute',
            bottom: 85,
            right: 0,
            background: '#FFFFFF',
            color: '#0F172A',
            padding: '12px 18px',
            borderRadius: '18px 18px 4px 18px',
            boxShadow: '0 10px 25px rgba(0,0,0,0.15)',
            border: '1px solid #E2E8F0',
            fontSize: 13,
            fontWeight: 600,
            width: 250,
            cursor: 'pointer',
            lineHeight: 1.4,
            display: 'flex',
            alignItems: 'center',
            gap: 10
          }}
        >
          <span style={{ fontSize: 20 }}>👋</span>
          <div>
            <strong>Oi! Eu sou a Sol! 👋</strong>
            <div style={{ fontSize: 11, color: '#64748B' }}>Dúvidas sobre remédios ou receitas?</div>
          </div>
        </div>
      )}

      {/* Floating Action Mascot Button */}
      <div
        onClick={() => setIsOpen(!isOpen)}
        style={{
          width: 72,
          height: 72,
          borderRadius: 9999,
          background: 'linear-gradient(135deg, #009B9D 0%, #DA1C82 100%)',
          padding: 3,
          boxShadow: '0 8px 25px rgba(0, 155, 157, 0.35)',
          cursor: 'pointer',
          position: 'relative'
        }}
      >
        <div
          style={{
            width: '100%',
            height: '100%',
            borderRadius: 9999,
            overflow: 'hidden',
            background: '#FFFFFF'
          }}
        >
          <img
            src="/imgs/mascote/mascote-circle.png"
            alt="Sol"
            style={{ width: '100%', height: '100%', objectFit: 'cover' }}
          />
        </div>
        <div
          style={{
            position: 'absolute',
            bottom: 2,
            right: 2,
            width: 16,
            height: 16,
            background: '#10B981',
            border: '3px solid #FFFFFF',
            borderRadius: 9999
          }}
        />
      </div>

      {/* Chat Window */}
      {isOpen && (
        <div
          style={{
            position: 'fixed',
            bottom: 105,
            right: 24,
            width: 380,
            maxWidth: 'calc(100vw - 32px)',
            height: 520,
            background: '#FFFFFF',
            borderRadius: 18,
            boxShadow: '0 15px 40px rgba(15, 23, 42, 0.25)',
            border: '1px solid #E2E8F0',
            display: 'flex',
            flexDirection: 'column',
            overflow: 'hidden',
            zIndex: 190
          }}
        >
          <div
            style={{
              background: 'linear-gradient(135deg, #009B9D 0%, #007678 100%)',
              color: '#FFFFFF',
              padding: 16,
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'space-between'
            }}
          >
            <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
              <div
                style={{
                  width: 42,
                  height: 42,
                  borderRadius: 9999,
                  overflow: 'hidden',
                  border: '2px solid #FFF',
                  background: '#FFF'
                }}
              >
                <img
                  src="/imgs/mascote/mascote-circle.png"
                  alt="Sol"
                  style={{ width: '100%', height: '100%', objectFit: 'cover' }}
                />
              </div>
              <div>
                <div style={{ fontWeight: 800, fontSize: 15 }}>Sol</div>
                <div style={{ fontSize: 11, opacity: 0.9 }}>
                  ● Farmacêutica Virtual Farma Gente
                </div>
              </div>
            </div>
            <button
              onClick={() => setIsOpen(false)}
              style={{ color: '#FFF', fontSize: 20, opacity: 0.8 }}
            >
              ✕
            </button>
          </div>

          <div
            style={{
              flex: 1,
              overflowY: 'auto',
              padding: 16,
              background: '#F8FAFC',
              display: 'flex',
              flexDirection: 'column',
              gap: 12
            }}
          >
            {messages.map((m, idx) => (
              <div
                key={idx}
                style={{
                  alignSelf: m.sender === 'user' ? 'flex-end' : 'flex-start',
                  background: m.sender === 'user' ? '#DA1C82' : '#FFFFFF',
                  color: m.sender === 'user' ? '#FFFFFF' : '#0F172A',
                  border: m.sender === 'user' ? 'none' : '1px solid #E2E8F0',
                  borderRadius: 14,
                  padding: '10px 14px',
                  fontSize: 13,
                  lineHeight: 1.45,
                  maxWidth: '85%'
                }}
              >
                <div>{m.text}</div>
                {m.link && (
                  <a
                    href={m.link}
                    target="_blank"
                    rel="noreferrer"
                    style={{
                      display: 'inline-block',
                      marginTop: 8,
                      background: '#25D366',
                      color: '#FFF',
                      padding: '6px 12px',
                      borderRadius: 20,
                      fontWeight: 700,
                      fontSize: 12
                    }}
                  >
                    💬 Abrir no WhatsApp
                  </a>
                )}
              </div>
            ))}
            <div ref={msgEndRef} />
          </div>

          {/* Chips */}
          <div
            style={{
              padding: '8px 12px',
              background: '#FFF',
              borderTop: '1px solid #E2E8F0',
              display: 'flex',
              gap: 6,
              overflowX: 'auto',
              whiteSpace: 'nowrap'
            }}
          >
            <button
              onClick={() => sendMessage('Quais as melhores ofertas de medicamentos?')}
              style={{
                background: '#F1F5F9',
                border: '1px solid #E2E8F0',
                padding: '4px 10px',
                borderRadius: 20,
                fontSize: 11,
                fontWeight: 700
              }}
            >
              🏷️ Ofertas
            </button>
            <button
              onClick={() => sendMessage('Como envio minha receita médica?')}
              style={{
                background: '#F1F5F9',
                border: '1px solid #E2E8F0',
                padding: '4px 10px',
                borderRadius: 20,
                fontSize: 11,
                fontWeight: 700
              }}
            >
              📋 Enviar Receita
            </button>
            <button
              onClick={() => sendMessage('Qual é o prazo de entrega em Itajaí?')}
              style={{
                background: '#F1F5F9',
                border: '1px solid #E2E8F0',
                padding: '4px 10px',
                borderRadius: 20,
                fontSize: 11,
                fontWeight: 700
              }}
            >
              🚚 Frete 1h
            </button>
          </div>

          <form
            onSubmit={(e) => {
              e.preventDefault();
              sendMessage(inputVal);
            }}
            style={{
              padding: '10px 14px',
              background: '#FFFFFF',
              borderTop: '1px solid #E2E8F0',
              display: 'flex',
              alignItems: 'center',
              gap: 8
            }}
          >
            <input
              type="text"
              value={inputVal}
              onChange={(e) => setInputVal(e.target.value)}
              placeholder="Digite sua mensagem ou remédio..."
              style={{
                flex: 1,
                border: '1px solid #CBD5E1',
                borderRadius: 20,
                padding: '8px 14px',
                fontSize: 13
              }}
            />
            <button
              type="submit"
              style={{
                background: '#DA1C82',
                color: '#FFF',
                width: 36,
                height: 36,
                borderRadius: 9999,
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center'
              }}
            >
              ➔
            </button>
          </form>
        </div>
      )}
    </div>
  );
}
