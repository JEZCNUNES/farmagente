import React, { useState, useEffect } from 'react';
import Link from 'next/link';
import { useRouter } from 'next/router';

export default function CartDrawer({ isOpen, onClose }) {
  const [items, setItems] = useState([]);
  const [coupon, setCoupon] = useState('');
  const [discountPercent, setDiscountPercent] = useState(0);
  const router = useRouter();

  const loadCart = () => {
    try {
      const saved = JSON.parse(localStorage.getItem('cm.cart') || '[]');
      setItems(saved);
      const appliedCoupon = localStorage.getItem('cm.coupon');
      if (appliedCoupon === 'FARMA10' || appliedCoupon === 'BEMVINDO') {
        setDiscountPercent(10);
      }
    } catch (e) {
      setItems([]);
    }
  };

  useEffect(() => {
    if (isOpen) {
      loadCart();
    }
  }, [isOpen]);

  const updateQuantity = (idx, delta) => {
    const updated = [...items];
    const newQty = (updated[idx].qty || updated[idx].quantity || 1) + delta;
    if (newQty <= 0) {
      updated.splice(idx, 1);
    } else {
      updated[idx].qty = newQty;
      updated[idx].quantity = newQty;
    }
    setItems(updated);
    localStorage.setItem('cm.cart', JSON.stringify(updated));
    window.dispatchEvent(new Event('storage'));
  };

  const removeItem = (idx) => {
    const updated = [...items];
    updated.splice(idx, 1);
    setItems(updated);
    localStorage.setItem('cm.cart', JSON.stringify(updated));
    window.dispatchEvent(new Event('storage'));
  };

  const subtotal = items.reduce((acc, it) => acc + (it.price * (it.qty || it.quantity || 1)), 0);
  const discount = (subtotal * discountPercent) / 100;
  const total = Math.max(0, subtotal - discount);
  const freeShippingThreshold = 149.00;
  const remainingForFreeShipping = Math.max(0, freeShippingThreshold - subtotal);
  const progressPercent = Math.min(100, (subtotal / freeShippingThreshold) * 100);

  const applyCoupon = (e) => {
    e.preventDefault();
    const clean = coupon.trim().toUpperCase();
    if (clean === 'FARMA10' || clean === 'BEMVINDO') {
      setDiscountPercent(10);
      localStorage.setItem('cm.coupon', clean);
      alert('Cupom de 10% aplicado com sucesso!');
    } else {
      alert('Cupom inválido. Use FARMA10');
    }
  };

  const formatMoney = (v) =>
    new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(v || 0);

  return (
    <>
      <div
        className={`cart-drawer-overlay ${isOpen ? 'open' : ''}`}
        onClick={onClose}
      />
      <aside className={`cart-drawer ${isOpen ? 'open' : ''}`}>
        <div className="cart-header">
          <h3>Sua Cesta ({items.reduce((acc, it) => acc + (it.qty || it.quantity || 1), 0)})</h3>
          <button className="cart-close-btn" onClick={onClose}>✕</button>
        </div>

        <div className="cart-free-shipping-bar">
          <div>
            {remainingForFreeShipping <= 0 ? (
              <span style={{ color: '#10B981', fontWeight: 800 }}>🎉 Parabéns! Você ganhou FRETE GRÁTIS!</span>
            ) : (
              <span>Faltam <strong>{formatMoney(remainingForFreeShipping)}</strong> para <strong>FRETE GRÁTIS!</strong></span>
            )}
          </div>
          <div className="progress-track">
            <div
              className="progress-fill"
              style={{
                width: `${progressPercent}%`,
                background: remainingForFreeShipping <= 0 ? '#10B981' : 'linear-gradient(90deg, #009B9D, #DA1C82)'
              }}
            />
          </div>
        </div>

        <div className="cart-items-list">
          {items.length === 0 ? (
            <div style={{ textAlign: 'center', padding: '40px 20px', color: '#94A3B8' }}>
              <p style={{ fontWeight: 700, fontSize: 16, color: '#1E293B', marginBottom: 6 }}>Sua cesta está vazia</p>
              <p style={{ fontSize: 13 }}>Adicione medicamentos, dermocosméticos ou produtos de higiene.</p>
            </div>
          ) : (
            items.map((it, idx) => (
              <div key={idx} className="cart-item">
                <img src={it.image} alt={it.name} />
                <div className="cart-item-info">
                  <div className="cart-item-title">{it.name}</div>
                  <div className="cart-item-price">{formatMoney(it.price)}</div>
                  <div className="cart-item-qty">
                    <button className="qty-btn" onClick={() => updateQuantity(idx, -1)}>-</button>
                    <span style={{ fontWeight: 700, fontSize: 13, minWidth: 20, textAlign: 'center' }}>
                      {it.qty || it.quantity || 1}
                    </span>
                    <button className="qty-btn" onClick={() => updateQuantity(idx, 1)}>+</button>
                    <button
                      onClick={() => removeItem(idx)}
                      style={{ marginLeft: 'auto', color: '#EF4444', fontSize: 11, fontWeight: 700 }}
                    >
                      Remover
                    </button>
                  </div>
                </div>
              </div>
            ))
          )}
        </div>

        <div className="cart-footer">
          <form onSubmit={applyCoupon} style={{ display: 'flex', gap: 8, marginBottom: 16 }}>
            <input
              type="text"
              placeholder="Cupom (ex: FARMA10)"
              value={coupon}
              onChange={(e) => setCoupon(e.target.value)}
              style={{
                flex: 1,
                border: '1px solid #CBD5E1',
                borderRadius: 8,
                padding: '8px 12px',
                fontSize: 13,
                textTransform: 'uppercase'
              }}
            />
            <button
              type="submit"
              style={{
                background: '#009B9D',
                color: '#FFF',
                padding: '8px 14px',
                borderRadius: 8,
                fontWeight: 700,
                fontSize: 13
              }}
            >
              Aplicar
            </button>
          </form>

          <div className="cart-subtotal-row">
            <span>Subtotal:</span>
            <span>{formatMoney(subtotal)}</span>
          </div>
          {discount > 0 && (
            <div className="cart-subtotal-row" style={{ color: '#059669' }}>
              <span>Desconto (10%):</span>
              <span>- {formatMoney(discount)}</span>
            </div>
          )}
          <div className="cart-total-row">
            <span>Total:</span>
            <span style={{ color: '#DA1C82' }}>{formatMoney(total)}</span>
          </div>

          <Link
            href="/checkout"
            className="cart-checkout-btn"
            style={{ display: 'block', textAlign: 'center' }}
            onClick={onClose}
          >
            Finalizar Pedido ➔
          </Link>
        </div>
      </aside>
    </>
  );
}
