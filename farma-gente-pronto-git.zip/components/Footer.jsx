import React from 'react';
import Link from 'next/link';

export default function Footer() {
  return (
    <footer className="footer-main">
      <div className="container">
        <div className="footer-grid">
          <div className="footer-col">
            <img src="/imgs/logo/logo-farma.png" alt="Rede Farma Gente" style={{ height: 44, marginBottom: 14 }} />
            <p style={{ fontSize: 13, lineHeight: 1.6, marginBottom: 16 }}>
              A Rede Farma Gente - Drogaria Itajaí cuida de quem importa com agilidade, medicamentos 100% originais e preços baixos.
            </p>
            <div style={{ fontWeight: 700, color: '#0F172A' }}>
              📞 Central: (47) 3348-1020<br />
              📱 WhatsApp: (47) 99988-7766
            </div>
          </div>

          <div className="footer-col">
            <h4>Institucional</h4>
            <ul className="footer-links">
              <li><Link href="/">Página Inicial</Link></li>
              <li><Link href="/loja">Catálogo Completo</Link></li>
              <li><Link href="/suporte">Sobre a Farmácia</Link></li>
              <li><Link href="/suporte">Nossas Unidades em Itajaí</Link></li>
            </ul>
          </div>

          <div className="footer-col">
            <h4>Atendimento</h4>
            <ul className="footer-links">
              <li><Link href="/rastrear">Rastreamento de Pedido</Link></li>
              <li><Link href="/suporte">Fale com o Farmacêutico</Link></li>
              <li><Link href="/admin">Painel Administrativo</Link></li>
            </ul>
          </div>

          <div className="footer-col">
            <h4>Segurança & Pagamentos</h4>
            <div style={{ fontSize: 13, lineHeight: 1.6, marginBottom: 12 }}>
              Pix com 5% de desconto imediato<br />
              Cartão de crédito em até 6x sem juros
            </div>
            <div style={{ color: '#10B981', fontWeight: 800, fontSize: 12 }}>
              🔒 Certificado SSL 256-bit<br />
              ✓ Farmácia Autorizada Anvisa
            </div>
          </div>
        </div>

        <div className="footer-regulatory">
          Razão Social: REDE FARMA GENTE DROGARIA ITAJAÍ LTDA | CNPJ: 14.852.963/0001-44<br />
          Endereço: Av. Sete de Setembro, 1200 - Centro, Itajaí - SC, CEP: 88301-202<br />
          Farmacêutica Responsável: Sol S. Silveira - CRF/SC nº 12.845 | AFE: 1.08451.2
        </div>

        <div className="footer-bottom">
          <div>© 2026 Rede Farma Gente - Drogaria Itajaí. Todos os direitos reservados.</div>
        </div>
      </div>
    </footer>
  );
}
