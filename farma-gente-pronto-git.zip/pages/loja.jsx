import React, { useState, useEffect } from 'react';
import Head from 'next/head';
import Link from 'next/link';
import { useRouter } from 'next/router';
import Header from '../components/Header';
import Footer from '../components/Footer';
import CartDrawer from '../components/CartDrawer';
import FarmaBot from '../components/FarmaBot';

export default function Loja() {
  const router = useRouter();
  const [products, setProducts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [selectedCategory, setSelectedCategory] = useState('Todos');
  const [selectedBrand, setSelectedBrand] = useState('Todos');
  const [sortBy, setSortBy] = useState('relevance');
  const [onlyFreeShipping, setOnlyFreeShipping] = useState(false);

  const categories = [
    'Todos',
    'Medicamentos',
    'Dermocosméticos',
    'Vitaminas',
    'Mamãe & Bebê',
    'Saúde & Aparelhos',
    'Linha Profissional',
    'Higiene & Beleza'
  ];

  const brands = [
    'Todos',
    'Sanofi',
    'Boehringer Ingelheim',
    'Laboratoires Théa',
    'Hypera Pharma',
    'Cimed',
    'Danone Nutrícia',
    'Abbott',
    'La Roche-Posay',
    'CeraVe',
    'Bayer',
    'L\'Oréal Professionnel',
    'Revlon',
    'Pampers',
    'Omron Healthcare',
    'G-Tech'
  ];

  useEffect(() => {
    async function load() {
      try {
        const res = await fetch('/api/products?limit=100');
        if (res.ok) {
          const data = await res.json();
          setProducts(Array.isArray(data) ? data : (data.products || []));
        } else {
          const fallback = await fetch('/clean_products.json');
          const data = await fallback.json();
          setProducts(Array.isArray(data) ? data : (data.products || []));
        }
      } catch (e) {
        console.warn('Erro ao carregar catálogo:', e);
      } finally {
        setLoading(false);
      }
    }
    load();
  }, []);

  useEffect(() => {
    if (router.query.cat) {
      setSelectedCategory(router.query.cat);
    }
  }, [router.query.cat]);

  const addToCart = (product) => {
    try {
      const cart = JSON.parse(localStorage.getItem('cm.cart') || '[]');
      const exist = cart.find((i) => String(i.id) === String(product.id));
      if (exist) {
        exist.qty = (exist.qty || 1) + 1;
      } else {
        cart.push({
          id: product.id,
          name: product.name,
          price: product.price,
          image: product.image,
          slug: product.slug,
          brand: product.brand,
          qty: 1
        });
      }
      localStorage.setItem('cm.cart', JSON.stringify(cart));
      window.dispatchEvent(new Event('storage'));
      setIsCartOpen(true);
    } catch (e) {}
  };

  const formatMoney = (val) =>
    new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(val || 0);

  const querySearch = (router.query.q || '').toLowerCase();
  let filtered = products.filter((p) => {
    if (selectedCategory !== 'Todos' && p.category !== selectedCategory) return false;
    if (selectedBrand !== 'Todos' && p.brand !== selectedBrand) return false;
    if (onlyFreeShipping && !p.freteGratis) return false;
    if (querySearch) {
      const matchName = (p.name || '').toLowerCase().includes(querySearch);
      const matchBrand = (p.brand || '').toLowerCase().includes(querySearch);
      const matchDesc = (p.description || '').toLowerCase().includes(querySearch);
      if (!matchName && !matchBrand && !matchDesc) return false;
    }
    return true;
  });

  if (sortBy === 'price-asc') filtered.sort((a, b) => a.price - b.price);
  if (sortBy === 'price-desc') filtered.sort((a, b) => b.price - a.price);
  if (sortBy === 'name') filtered.sort((a, b) => a.name.localeCompare(b.name));

  return (
    <>
      <Head>
        <title>Catálogo Completo | Rede Farma Gente - Drogaria Itajaí</title>
      </Head>

      <Header onOpenCart={() => setIsCartOpen(true)} />

      <main className="container" style={{ marginTop: 24, marginBottom: 60 }}>
        <div style={{ display: 'flex', gap: 28, alignItems: 'flex-start' }}>
          {/* Sidebar */}
          <aside style={{ width: 260, flexShrink: 0, background: '#FFF', border: '1px solid #E2E8F0', borderRadius: 12, padding: 20 }}>
            <h3 style={{ fontFamily: 'var(--font-title)', fontSize: 16, fontWeight: 800, marginBottom: 16 }}>Filtrar Catálogo</h3>

            <div style={{ marginBottom: 20 }}>
              <h4 style={{ fontSize: 13, fontWeight: 700, color: '#64748B', textTransform: 'uppercase', marginBottom: 10 }}>Categorias</h4>
              <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
                {categories.map((c) => (
                  <button
                    key={c}
                    onClick={() => setSelectedCategory(c)}
                    style={{
                      textAlign: 'left',
                      fontSize: 13,
                      padding: '4px 0',
                      color: selectedCategory === c ? '#009B9D' : '#334155',
                      fontWeight: selectedCategory === c ? 800 : 500
                    }}
                  >
                    {c}
                  </button>
                ))}
              </div>
            </div>

            <div style={{ marginBottom: 20, borderTop: '1px solid #E2E8F0', paddingTop: 16 }}>
              <h4 style={{ fontSize: 13, fontWeight: 700, color: '#64748B', textTransform: 'uppercase', marginBottom: 10 }}>Marcas e Laboratórios</h4>
              <select
                value={selectedBrand}
                onChange={(e) => setSelectedBrand(e.target.value)}
                style={{ width: '100%', border: '1px solid #CBD5E1', borderRadius: 8, padding: 8, fontSize: 13 }}
              >
                {brands.map((b) => (
                  <option key={b} value={b}>{b}</option>
                ))}
              </select>
            </div>

            <div style={{ borderTop: '1px solid #E2E8F0', paddingTop: 16 }}>
              <label style={{ display: 'flex', alignItems: 'center', gap: 8, fontSize: 13, cursor: 'pointer' }}>
                <input
                  type="checkbox"
                  checked={onlyFreeShipping}
                  onChange={(e) => setOnlyFreeShipping(e.target.checked)}
                />
                Apenas com Frete Grátis
              </label>
            </div>
          </aside>

          {/* Main Grid */}
          <section style={{ flex: 1 }}>
            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', background: '#FFF', border: '1px solid #E2E8F0', borderRadius: 12, padding: '14px 20px', marginBottom: 20 }}>
              <div style={{ fontSize: 14, fontWeight: 700, color: '#0F172A' }}>
                {filtered.length} produtos encontrados
              </div>
              <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
                <span style={{ fontSize: 13, color: '#64748B', fontWeight: 600 }}>Ordenar por:</span>
                <select
                  value={sortBy}
                  onChange={(e) => setSortBy(e.target.value)}
                  style={{ border: '1px solid #CBD5E1', borderRadius: 8, padding: '6px 12px', fontSize: 13 }}
                >
                  <option value="relevance">Mais Relevantes</option>
                  <option value="price-asc">Menor Preço</option>
                  <option value="price-desc">Maior Preço</option>
                  <option value="name">Nome A-Z</option>
                </select>
              </div>
            </div>

            <div className="shelf-grid" style={{ gridTemplateColumns: 'repeat(4, 1fr)' }}>
              {filtered.map((p) => (
                <article key={p.id} className="product-card">
                  {p.discountPercent > 0 && <div className="product-card-discount">-{p.discountPercent}%</div>}
                  {p.badge && <div className="product-card-badge">{p.badge}</div>}

                  <Link href={`/produto/${p.slug}`} className="product-card-img-wrap">
                    <img src={p.image} alt={p.name} loading="lazy" />
                  </Link>

                  <div className="product-brand">{p.brand || 'Farma Gente'}</div>
                  <Link href={`/produto/${p.slug}`}>
                    <h3 className="product-title">{p.name}</h3>
                  </Link>

                  <div className="product-rating">
                    ★★★★★ <span>({p.reviews || 48})</span>
                  </div>

                  <div className="product-price-box">
                    <div className="price-details">
                      {p.oldPrice && <div className="price-old">{formatMoney(p.oldPrice)}</div>}
                      <div className="price-current">{formatMoney(p.price)}</div>
                      <div className="price-pix">no Pix: <strong>{formatMoney(p.price * 0.95)}</strong></div>
                    </div>

                    <button className="btn-add-cart-circle" title="Adicionar à Cesta" onClick={() => addToCart(p)}>
                      +
                    </button>
                  </div>
                </article>
              ))}
            </div>
          </section>
        </div>
      </main>

      <Footer />
      <FarmaBot />
      <CartDrawer isOpen={isCartOpen} onClose={() => setIsCartOpen(false)} />
    </>
  );
}
