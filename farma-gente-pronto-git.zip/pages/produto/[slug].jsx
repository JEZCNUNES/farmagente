import React, { useState, useEffect } from 'react';
import Head from 'next/head';
import Link from 'next/link';
import { useRouter } from 'next/router';
import Header from '../../components/Header';
import Footer from '../../components/Footer';
import CartDrawer from '../../components/CartDrawer';
import FarmaBot from '../../components/FarmaBot';

export default function ProdutoDetalhe() {
  const router = useRouter();
  const { slug } = router.query;
  const [product, setProduct] = useState(null);
  const [loading, setLoading] = useState(true);
  const [qty, setQty] = useState(1);
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [cep, setCep] = useState('');
  const [shippingResult, setShippingResult] = useState(null);
  const [calculatingShipping, setCalculatingShipping] = useState(false);

  useEffect(() => {
    if (!slug) return;
    async function loadProduct() {
      try {
        const res = await fetch(`/api/products/${slug}`);
        if (res.ok) {
          const data = await res.json();
          setProduct(data);
        } else {
          const fallback = await fetch('/clean_products.json');
          const all = await fallback.json();
          const found = all.find((p) => p.slug === slug);
          setProduct(found || null);
        }
      } catch (e) {
        console.error(e);
      } finally {
        setLoading(false);
      }
    }
    loadProduct();
  }, [slug]);

  const addToCart = () => {
    if (!product) return;
    try {
      const cart = JSON.parse(localStorage.getItem('cm.cart') || '[]');
      const exist = cart.find((i) => String(i.id) === String(product.id));
      if (exist) {
        exist.qty = (exist.qty || 1) + qty;
      } else {
        cart.push({
          id: product.id,
          name: product.name,
          price: product.price,
          image: product.image,
          slug: product.slug,
          brand: product.brand,
          qty
        });
      }
      localStorage.setItem('cm.cart', JSON.stringify(cart));
      window.dispatchEvent(new Event('storage'));
      setIsCartOpen(true);
    } catch (e) {}
  };

  const handleCalcShipping = async (e) => {
    e.preventDefault();
    if (!cep || !product) return;
    setCalculatingShipping(true);
    try {
      const res = await fetch('/api/shipping/calculate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ cep, subtotal: product.price * qty, items: [{ ...product, quantity: qty }] })
      });
      const data = await res.json();
      if (data.quotes && data.quotes.length > 0) {
        setShippingResult(data.quotes);
      } else {
        setShippingResult([
          { name: 'Entrega Expressa Itajaí (Até 1h)', price: 9.90, deliveryTime: 1 },
          { name: 'Retirada em Loja Centro Itajaí', price: 0, deliveryTime: 0 }
        ]);
      }
    } catch (err) {
      setShippingResult([
        { name: 'Entrega Expressa Itajaí (Até 1h)', price: 9.90, deliveryTime: 1 },
        { name: 'Retirada em Loja Centro Itajaí', price: 0, deliveryTime: 0 }
      ]);
    } finally {
      setCalculatingShipping(false);
    }
  };

  const formatMoney = (val) =>
    new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(val || 0);

  if (loading) {
    return (
      <>
        <Header onOpenCart={() => setIsCartOpen(true)} />
        <div className="container" style={{ padding: '60px 0', textAlign: 'center' }}>
          Carregando informações farmacêuticas...
        </div>
        <Footer />
      </>
    );
  }

  if (!product) {
    return (
      <>
        <Header onOpenCart={() => setIsCartOpen(true)} />
        <div className="container" style={{ padding: '60px 0', textAlign: 'center' }}>
          <h2>Produto não encontrado</h2>
          <Link href="/loja" style={{ color: '#009B9D', fontWeight: 700, marginTop: 12, display: 'inline-block' }}>
            Voltar para o Catálogo ➔
          </Link>
        </div>
        <Footer />
      </>
    );
  }

  const pixPrice = product.price * 0.95;

  return (
    <>
      <Head>
        <title>{product.name} | Rede Farma Gente - Drogaria Itajaí</title>
        <meta name="description" content={product.short || product.name} />
      </Head>

      <Header onOpenCart={() => setIsCartOpen(true)} />

      <main className="container" style={{ marginTop: 24, marginBottom: 60 }}>
        <div style={{ fontSize: 13, color: '#64748B', marginBottom: 20 }}>
          <Link href="/">Início</Link> / <Link href="/loja">Catálogo</Link> / <span style={{ color: '#0F172A', fontWeight: 700 }}>{product.name}</span>
        </div>

        <div style={{ background: '#FFF', border: '1px solid #E2E8F0', borderRadius: 16, padding: 32, display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 40, marginBottom: 40 }}>
          {/* Image */}
          <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', background: '#F8FAFC', borderRadius: 12, padding: 30, position: 'relative' }}>
            {product.discountPercent > 0 && (
              <span className="product-card-discount" style={{ top: 16, right: 16, fontSize: 13, padding: '4px 10px' }}>
                -{product.discountPercent}%
              </span>
            )}
            <img src={product.image} alt={product.name} style={{ maxWidth: '80%', maxHeight: 360, objectFit: 'contain' }} />
          </div>

          {/* Details */}
          <div>
            <div style={{ fontSize: 12, fontWeight: 800, color: '#009B9D', textTransform: 'uppercase', letterSpacing: 1, marginBottom: 6 }}>
              {product.brand}
            </div>
            <h1 style={{ fontFamily: 'var(--font-title)', fontSize: 24, fontWeight: 800, color: '#0F172A', lineHeight: 1.3, marginBottom: 12 }}>
              {product.name}
            </h1>

            <div style={{ display: 'flex', alignItems: 'center', gap: 12, marginBottom: 16 }}>
              <div style={{ color: '#F59E0B', fontWeight: 700, fontSize: 14 }}>
                ★★★★★ <span style={{ color: '#64748B', fontWeight: 500 }}>({product.reviews || 48} avaliações)</span>
              </div>
              <span style={{ background: '#DCFCE7', color: '#166534', fontSize: 11, fontWeight: 800, padding: '2px 8px', borderRadius: 4 }}>
                EM ESTOQUE
              </span>
            </div>

            <p style={{ fontSize: 14, color: '#475569', lineHeight: 1.6, marginBottom: 20 }}>
              {product.short}
            </p>

            <div style={{ background: '#F8FAFC', border: '1px solid #E2E8F0', borderRadius: 12, padding: 20, marginBottom: 24 }}>
              {product.oldPrice && (
                <div style={{ fontSize: 14, color: '#94A3B8', textDecoration: 'line-through' }}>
                  {formatMoney(product.oldPrice)}
                </div>
              )}
              <div style={{ display: 'flex', alignItems: 'baseline', gap: 8 }}>
                <div style={{ fontFamily: 'var(--font-title)', fontSize: 32, fontWeight: 900, color: '#0F172A' }}>
                  {formatMoney(product.price)}
                </div>
                <div style={{ color: '#64748B', fontSize: 13 }}>à vista no cartão ou boleto</div>
              </div>
              <div style={{ fontSize: 14, color: '#059669', fontWeight: 800, marginTop: 4 }}>
                ou {formatMoney(pixPrice)} no PIX com 5% de desconto extra!
              </div>
            </div>

            <div style={{ display: 'flex', gap: 16, alignItems: 'center', marginBottom: 24 }}>
              <div style={{ display: 'flex', alignItems: 'center', border: '1px solid #CBD5E1', borderRadius: 8, padding: '4px 8px', gap: 10 }}>
                <button onClick={() => setQty((prev) => Math.max(1, prev - 1))} style={{ fontSize: 18, fontWeight: 800, width: 24 }}>-</button>
                <span style={{ fontWeight: 800, fontSize: 15, minWidth: 24, textAlign: 'center' }}>{qty}</span>
                <button onClick={() => setQty((prev) => prev + 1)} style={{ fontSize: 18, fontWeight: 800, width: 24 }}>+</button>
              </div>

              <button
                onClick={addToCart}
                style={{
                  flex: 1,
                  background: '#DA1C82',
                  color: '#FFF',
                  padding: '14px 24px',
                  borderRadius: 8,
                  fontWeight: 800,
                  fontSize: 16,
                  boxShadow: '0 4px 14px rgba(218,28,130,0.3)',
                  cursor: 'pointer'
                }}
              >
                🛒 Adicionar à Cesta
              </button>
            </div>

            {/* Shipping */}
            <div style={{ borderTop: '1px solid #E2E8F0', paddingTop: 20 }}>
              <div style={{ fontSize: 13, fontWeight: 700, color: '#0F172A', marginBottom: 8 }}>
                Calcular Frete e Prazo de Entrega:
              </div>
              <form onSubmit={handleCalcShipping} style={{ display: 'flex', gap: 10 }}>
                <input
                  type="text"
                  placeholder="Digite seu CEP (Ex: 88301-202)"
                  maxLength={9}
                  value={cep}
                  onChange={(e) => setCep(e.target.value)}
                  style={{ flex: 1, border: '1px solid #CBD5E1', borderRadius: 8, padding: 10, fontSize: 14 }}
                />
                <button
                  type="submit"
                  disabled={calculatingShipping}
                  style={{ background: '#009B9D', color: '#FFF', padding: '10px 18px', borderRadius: 8, fontWeight: 700, fontSize: 13 }}
                >
                  {calculatingShipping ? 'Calculando...' : 'Calcular'}
                </button>
              </form>

              {shippingResult && (
                <div style={{ marginTop: 12 }}>
                  {shippingResult.map((q, i) => (
                    <div key={i} style={{ display: 'flex', justifyContent: 'space-between', padding: '6px 0', borderBottom: '1px dashed #E2E8F0', fontSize: 13 }}>
                      <span><strong>{q.name}</strong> ({q.deliveryTime} dias)</span>
                      <span style={{ fontWeight: 800, color: '#0F172A' }}>
                        {q.price === 0 ? 'GRÁTIS' : formatMoney(q.price)}
                      </span>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Technical Specs */}
        <div style={{ background: '#FFF', border: '1px solid #E2E8F0', borderRadius: 16, padding: 32 }}>
          <h2 style={{ fontFamily: 'var(--font-title)', fontSize: 20, fontWeight: 800, marginBottom: 16, color: '#0F172A' }}>
            Bula & Informações Farmacêuticas
          </h2>
          <p style={{ fontSize: 14, color: '#334155', lineHeight: 1.8, marginBottom: 24 }}>
            {product.description}
          </p>

          {product.specs && (
            <>
              <h3 style={{ fontSize: 16, fontWeight: 800, marginBottom: 12, color: '#0F172A' }}>
                Especificações Técnicas
              </h3>
              <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: 13 }}>
                <tbody>
                  {Object.entries(product.specs).map(([k, v]) => (
                    <tr key={k} style={{ borderBottom: '1px solid #E2E8F0' }}>
                      <td style={{ padding: 10, fontWeight: 700, color: '#64748B', width: 240, background: '#F8FAFC' }}>{k}</td>
                      <td style={{ padding: 10, color: '#0F172A' }}>{v}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </>
          )}
        </div>
      </main>

      <Footer />
      <FarmaBot />
      <CartDrawer isOpen={isCartOpen} onClose={() => setIsCartOpen(false)} />
    </>
  );
}
