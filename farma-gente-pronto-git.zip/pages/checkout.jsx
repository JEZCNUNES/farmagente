import React, { useState, useEffect } from 'react';
import Head from 'next/head';
import Link from 'next/link';
import Header from '../components/Header';
import Footer from '../components/Footer';

export default function Checkout() {
  const [cartItems, setCartItems] = useState([]);
  const [subtotal, setSubtotal] = useState(0);

  // Form states
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [phone, setPhone] = useState('');
  const [cpf, setCpf] = useState('');

  // Address states
  const [cep, setCep] = useState('');
  const [street, setStreet] = useState('');
  const [number, setNumber] = useState('');
  const [complement, setComplement] = useState('');
  const [district, setDistrict] = useState('');
  const [city, setCity] = useState('');
  const [state, setState] = useState('');

  // Shipping
  const [shippingQuotes, setShippingQuotes] = useState([]);
  const [selectedShipping, setSelectedShipping] = useState(null);
  const [shippingLoading, setShippingLoading] = useState(false);

  // Payment
  const [paymentMethod, setPaymentMethod] = useState('PIX');
  const [cardNumber, setCardNumber] = useState('');
  const [cardHolder, setCardHolder] = useState('');
  const [cardExpiry, setCardExpiry] = useState('');
  const [cardCvv, setCardCvv] = useState('');
  const [installments, setInstallments] = useState(1);

  // Status
  const [loading, setLoading] = useState(false);
  const [orderSuccess, setOrderSuccess] = useState(null);

  useEffect(() => {
    try {
      const saved = JSON.parse(localStorage.getItem('cm.cart') || '[]');
      if (saved.length === 0) {
        window.location.href = '/carrinho';
        return;
      }
      setCartItems(saved);
      const sub = saved.reduce((acc, it) => acc + (parseFloat(it.price) * (it.qty || 1)), 0);
      setSubtotal(sub);
    } catch (e) {
      window.location.href = '/carrinho';
    }
  }, []);

  const handleCepBlur = async () => {
    const cleanCep = cep.replace(/\D/g, '');
    if (cleanCep.length !== 8) return;

    setShippingLoading(true);
    try {
      // 1. ViaCEP
      const viaRes = await fetch(`https://viacep.com.br/ws/${cleanCep}/json/`);
      const viaData = await viaRes.json();
      if (!viaData.erro) {
        setStreet(viaData.logradouro || '');
        setDistrict(viaData.bairro || '');
        setCity(viaData.localidade || '');
        setState(viaData.uf || '');
      }

      // 2. Shipping Quotes
      const shipRes = await fetch('/api/shipping/calculate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          destinationCep: cleanCep,
          subtotal,
          items: cartItems.map((i) => ({
            id: i.id,
            name: i.name,
            price: i.price,
            quantity: i.qty || 1,
            weight: 1,
            height: 20,
            width: 20,
            length: 20,
          })),
        }),
      });

      const shipData = await shipRes.json();
      if (shipData.quotes && shipData.quotes.length > 0) {
        setShippingQuotes(shipData.quotes);
        setSelectedShipping(shipData.quotes[0]);
      }
    } catch (err) {
      console.warn('Erro ao consultar CEP:', err);
    } finally {
      setShippingLoading(false);
    }
  };

  const shippingCost = selectedShipping ? parseFloat(selectedShipping.price) : (subtotal >= 199 ? 0 : 25);
  const pixDiscount = paymentMethod === 'PIX' ? subtotal * 0.10 : 0;
  const total = Math.max(subtotal + shippingCost - pixDiscount, 0);

  const handleSubmitOrder = async (e) => {
    e.preventDefault();
    setLoading(true);

    try {
      const payload = {
        customer: {
          name,
          email,
          phone,
          cpf,
        },
        shippingAddress: {
          cep,
          street,
          number,
          complement,
          district,
          city,
          state,
        },
        items: cartItems.map((it) => ({
          productId: String(it.id),
          name: it.name,
          price: it.price,
          quantity: it.qty || 1,
          image: it.image,
        })),
        paymentMethod,
        shippingMethod: selectedShipping?.name || 'Padrão BR Express',
        shippingCost,
        discount: pixDiscount,
        installments,
      };

      if (paymentMethod === 'CREDIT_CARD') {
        const [m, y] = cardExpiry.split('/');
        payload.cardData = {
          cardNumber,
          holderName: cardHolder,
          expiryMonth: m || '12',
          expiryYear: y ? `20${y}` : '2028',
          ccv: cardCvv,
        };
      }

      const res = await fetch('/api/checkout', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      });

      const data = await res.json();
      if (!res.ok) {
        throw new Error(data.error || 'Falha ao processar checkout');
      }

      setOrderSuccess(data);
      localStorage.removeItem('cm.cart');
      window.dispatchEvent(new Event('cart-updated'));
    } catch (err) {
      alert(err.message || 'Erro ao concluir o pedido. Tente novamente.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <>
      <Head>
        <title>Finalizar Compra Segura | BR Distribuidora Oficial</title>
        <link rel="icon" type="image/png" href="/imgs/br/logo-color.png" />
      </Head>

      <Header />

      <main style={{ padding: '24px 0 60px', minHeight: '80vh' }}>
        <div className="container">
          {orderSuccess ? (
            /* Order Success View */
            <div
              style={{
                maxWidth: '640px',
                margin: '0 auto',
                background: '#FFFFFF',
                padding: '40px 30px',
                borderRadius: '8px',
                border: '1px solid var(--border-light)',
                textAlign: 'center',
                boxShadow: 'var(--shadow-card)'
              }}
            >
              <img
                src="/imgs/br/mascote-thumbsup.png"
                alt="Fox Mascote BR"
                style={{ width: '110px', margin: '0 auto 16px' }}
              />
              <h2 style={{ fontSize: '22px', fontWeight: 900, color: 'var(--text-black)', marginBottom: '6px' }}>
                Pedido Realizado com Sucesso!
              </h2>
              <p style={{ color: 'var(--text-gray)', fontSize: '13px', marginBottom: '20px' }}>
                Número do Pedido: <strong style={{ color: 'var(--kabum-orange)', fontSize: '16px' }}>#{orderSuccess.orderNumber}</strong>
              </p>

              {paymentMethod === 'PIX' && orderSuccess.pixCopiaECola && (
                <div
                  style={{
                    background: '#F0FDF4',
                    border: '1px solid #BBF7D0',
                    borderRadius: '8px',
                    padding: '20px',
                    marginBottom: '20px'
                  }}
                >
                  <div style={{ fontWeight: 800, color: 'var(--color-green)', fontSize: '14px', marginBottom: '10px' }}>
                    Pague via Pix para aprovação imediata:
                  </div>

                  {orderSuccess.pixQrCode && (
                    <div style={{ margin: '14px auto', display: 'inline-block', background: 'white', padding: '10px', borderRadius: '8px', border: '1px solid var(--border-light)' }}>
                      <img
                        src={`data:image/png;base64,${orderSuccess.pixQrCode}`}
                        alt="QR Code Pix"
                        style={{ width: '180px', height: '180px' }}
                      />
                    </div>
                  )}

                  <div style={{ margin: '12px 0 6px', fontSize: '12px', color: 'var(--text-gray)' }}>
                    Ou copie e cole o código abaixo no app do seu banco:
                  </div>

                  <div style={{ display: 'flex', gap: '8px', maxWidth: '480px', margin: '0 auto' }}>
                    <input
                      type="text"
                      readOnly
                      value={orderSuccess.pixCopiaECola}
                      style={{
                        flex: 1,
                        padding: '8px 10px',
                        background: '#FFFFFF',
                        border: '1px solid var(--border-light)',
                        borderRadius: '4px',
                        fontSize: '11px',
                        color: 'var(--text-dark)'
                      }}
                    />
                    <button
                      onClick={() => {
                        navigator.clipboard.writeText(orderSuccess.pixCopiaECola);
                        alert('Código Pix copiado para a área de transferência!');
                      }}
                      style={{
                        background: 'var(--color-green)',
                        color: 'white',
                        border: 'none',
                        padding: '0 16px',
                        borderRadius: '4px',
                        fontSize: '12px',
                        fontWeight: 700,
                        cursor: 'pointer'
                      }}
                    >
                      Copiar
                    </button>
                  </div>
                </div>
              )}

              <div style={{ display: 'flex', gap: '12px', justifyContent: 'center' }}>
                <Link
                  href={`/rastrear?id=${orderSuccess.orderNumber}`}
                  style={{
                    background: '#F1F5F9',
                    border: '1px solid var(--border-light)',
                    color: 'var(--text-dark)',
                    padding: '10px 20px',
                    borderRadius: '4px',
                    fontWeight: 700,
                    fontSize: '12.5px'
                  }}
                >
                  Acompanhar Pedido
                </Link>
                <Link
                  href="/loja"
                  style={{
                    background: 'var(--kabum-orange)',
                    color: '#FFF',
                    padding: '10px 20px',
                    borderRadius: '4px',
                    fontWeight: 800,
                    fontSize: '12.5px'
                  }}
                >
                  Continuar Comprando
                </Link>
              </div>
            </div>
          ) : (
            <form onSubmit={handleSubmitOrder} style={{ display: 'grid', gridTemplateColumns: '1fr 380px', gap: '24px', alignItems: 'flex-start' }}>
              <div>
                {/* 1. Identification */}
                <div style={{ background: '#FFFFFF', border: '1px solid var(--border-light)', borderRadius: '8px', padding: '20px', marginBottom: '20px', boxShadow: 'var(--shadow-card)' }}>
                  <h3 style={{ fontSize: '14px', fontWeight: 800, color: 'var(--text-black)', marginBottom: '14px', textTransform: 'uppercase' }}>
                    1. Dados de Faturamento & Contato
                  </h3>

                  <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '12px' }}>
                    <div style={{ gridColumn: '1 / -1' }}>
                      <label style={{ display: 'block', fontSize: '11.5px', color: 'var(--text-gray)', marginBottom: '4px', fontWeight: 600 }}>Nome Completo ou Razão Social *</label>
                      <input
                        type="text"
                        required
                        value={name}
                        onChange={(e) => setName(e.target.value)}
                        placeholder="Nome ou Empresa"
                        style={{ width: '100%', padding: '9px 12px', background: '#FFFFFF', border: '1px solid var(--border-light)', borderRadius: '4px', fontSize: '13px', outline: 'none' }}
                      />
                    </div>
                    <div>
                      <label style={{ display: 'block', fontSize: '11.5px', color: 'var(--text-gray)', marginBottom: '4px', fontWeight: 600 }}>E-mail *</label>
                      <input
                        type="email"
                        required
                        value={email}
                        onChange={(e) => setEmail(e.target.value)}
                        placeholder="seu@email.com.br"
                        style={{ width: '100%', padding: '9px 12px', background: '#FFFFFF', border: '1px solid var(--border-light)', borderRadius: '4px', fontSize: '13px', outline: 'none' }}
                      />
                    </div>
                    <div>
                      <label style={{ display: 'block', fontSize: '11.5px', color: 'var(--text-gray)', marginBottom: '4px', fontWeight: 600 }}>WhatsApp / Telefone *</label>
                      <input
                        type="text"
                        required
                        value={phone}
                        onChange={(e) => setPhone(e.target.value)}
                        placeholder="(00) 00000-0000"
                        style={{ width: '100%', padding: '9px 12px', background: '#FFFFFF', border: '1px solid var(--border-light)', borderRadius: '4px', fontSize: '13px', outline: 'none' }}
                      />
                    </div>
                    <div style={{ gridColumn: '1 / -1' }}>
                      <label style={{ display: 'block', fontSize: '11.5px', color: 'var(--text-gray)', marginBottom: '4px', fontWeight: 600 }}>CPF ou CNPJ *</label>
                      <input
                        type="text"
                        required
                        value={cpf}
                        onChange={(e) => setCpf(e.target.value)}
                        placeholder="000.000.000-00 ou 00.000.000/0000-00"
                        style={{ width: '100%', padding: '9px 12px', background: '#FFFFFF', border: '1px solid var(--border-light)', borderRadius: '4px', fontSize: '13px', outline: 'none' }}
                      />
                    </div>
                  </div>
                </div>

                {/* 2. Shipping Address */}
                <div style={{ background: '#FFFFFF', border: '1px solid var(--border-light)', borderRadius: '8px', padding: '20px', marginBottom: '20px', boxShadow: 'var(--shadow-card)' }}>
                  <h3 style={{ fontSize: '14px', fontWeight: 800, color: 'var(--text-black)', marginBottom: '14px', textTransform: 'uppercase' }}>
                    2. Endereço de Entrega
                  </h3>

                  <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '12px' }}>
                    <div>
                      <label style={{ display: 'block', fontSize: '11.5px', color: 'var(--text-gray)', marginBottom: '4px', fontWeight: 600 }}>CEP *</label>
                      <input
                        type="text"
                        required
                        maxLength={9}
                        value={cep}
                        onBlur={handleCepBlur}
                        onChange={(e) => setCep(e.target.value)}
                        placeholder="00000-000"
                        style={{ width: '100%', padding: '9px 12px', background: '#FFFFFF', border: '1px solid var(--border-light)', borderRadius: '4px', fontSize: '13px', outline: 'none' }}
                      />
                    </div>
                    <div style={{ display: 'flex', alignItems: 'flex-end', paddingBottom: '6px' }}>
                      <span style={{ fontSize: '11.5px', color: 'var(--text-gray)' }}>
                        {shippingLoading ? 'Consultando transportadoras...' : 'Digite o CEP para preencher o endereço'}
                      </span>
                    </div>
                    <div style={{ gridColumn: '1 / -1' }}>
                      <label style={{ display: 'block', fontSize: '11.5px', color: 'var(--text-gray)', marginBottom: '4px', fontWeight: 600 }}>Logradouro (Rua, Av.) *</label>
                      <input
                        type="text"
                        required
                        value={street}
                        onChange={(e) => setStreet(e.target.value)}
                        style={{ width: '100%', padding: '9px 12px', background: '#FFFFFF', border: '1px solid var(--border-light)', borderRadius: '4px', fontSize: '13px', outline: 'none' }}
                      />
                    </div>
                    <div>
                      <label style={{ display: 'block', fontSize: '11.5px', color: 'var(--text-gray)', marginBottom: '4px', fontWeight: 600 }}>Número *</label>
                      <input
                        type="text"
                        required
                        value={number}
                        onChange={(e) => setNumber(e.target.value)}
                        style={{ width: '100%', padding: '9px 12px', background: '#FFFFFF', border: '1px solid var(--border-light)', borderRadius: '4px', fontSize: '13px', outline: 'none' }}
                      />
                    </div>
                    <div>
                      <label style={{ display: 'block', fontSize: '11.5px', color: 'var(--text-gray)', marginBottom: '4px', fontWeight: 600 }}>Complemento</label>
                      <input
                        type="text"
                        value={complement}
                        onChange={(e) => setComplement(e.target.value)}
                        placeholder="Galpão, Sala, Andar"
                        style={{ width: '100%', padding: '9px 12px', background: '#FFFFFF', border: '1px solid var(--border-light)', borderRadius: '4px', fontSize: '13px', outline: 'none' }}
                      />
                    </div>
                    <div>
                      <label style={{ display: 'block', fontSize: '11.5px', color: 'var(--text-gray)', marginBottom: '4px', fontWeight: 600 }}>Bairro *</label>
                      <input
                        type="text"
                        required
                        value={district}
                        onChange={(e) => setDistrict(e.target.value)}
                        style={{ width: '100%', padding: '9px 12px', background: '#FFFFFF', border: '1px solid var(--border-light)', borderRadius: '4px', fontSize: '13px', outline: 'none' }}
                      />
                    </div>
                    <div style={{ display: 'grid', gridTemplateColumns: '1fr 70px', gap: '8px' }}>
                      <div>
                        <label style={{ display: 'block', fontSize: '11.5px', color: 'var(--text-gray)', marginBottom: '4px', fontWeight: 600 }}>Cidade *</label>
                        <input
                          type="text"
                          required
                          value={city}
                          onChange={(e) => setCity(e.target.value)}
                          style={{ width: '100%', padding: '9px 12px', background: '#FFFFFF', border: '1px solid var(--border-light)', borderRadius: '4px', fontSize: '13px', outline: 'none' }}
                        />
                      </div>
                      <div>
                        <label style={{ display: 'block', fontSize: '11.5px', color: 'var(--text-gray)', marginBottom: '4px', fontWeight: 600 }}>UF *</label>
                        <input
                          type="text"
                          required
                          maxLength={2}
                          value={state}
                          onChange={(e) => setState(e.target.value)}
                          style={{ width: '100%', padding: '9px 6px', textAlign: 'center', background: '#FFFFFF', border: '1px solid var(--border-light)', borderRadius: '4px', fontSize: '13px', outline: 'none' }}
                        />
                      </div>
                    </div>
                  </div>

                  {/* Shipping Options */}
                  {shippingQuotes.length > 0 && (
                    <div style={{ marginTop: '16px', paddingTop: '14px', borderTop: '1px solid var(--border-subtle)' }}>
                      <label style={{ display: 'block', fontSize: '12px', fontWeight: 800, color: 'var(--text-black)', marginBottom: '8px' }}>
                        Modalidade de Envio:
                      </label>
                      <div style={{ display: 'flex', flexDirection: 'column', gap: '6px' }}>
                        {shippingQuotes.map((q, idx) => (
                          <label
                            key={idx}
                            style={{
                              display: 'flex',
                              alignItems: 'center',
                              justifyContent: 'space-between',
                              padding: '8px 12px',
                              background: selectedShipping?.name === q.name ? '#EBF4FC' : '#FFFFFF',
                              border: selectedShipping?.name === q.name ? '1px solid var(--kabum-blue)' : '1px solid var(--border-light)',
                              borderRadius: '4px',
                              cursor: 'pointer'
                            }}
                          >
                            <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                              <input
                                type="radio"
                                name="shippingMethod"
                                checked={selectedShipping?.name === q.name}
                                onChange={() => setSelectedShipping(q)}
                                style={{ accentColor: 'var(--kabum-blue)' }}
                              />
                              <div>
                                <strong style={{ color: 'var(--text-black)', fontSize: '12.5px', display: 'block' }}>{q.name}</strong>
                                <span style={{ fontSize: '11px', color: 'var(--text-gray)' }}>Prazo: até {q.delivery_time} dias úteis</span>
                              </div>
                            </div>
                            <span style={{ fontWeight: 800, color: q.price === 0 ? 'var(--color-green)' : 'var(--text-black)', fontSize: '12.5px' }}>
                              {q.price === 0 ? 'GRÁTIS' : `R$ ${parseFloat(q.price).toFixed(2).replace('.', ',')}`}
                            </span>
                          </label>
                        ))}
                      </div>
                    </div>
                  )}
                </div>

                {/* 3. Payment Method */}
                <div style={{ background: '#FFFFFF', border: '1px solid var(--border-light)', borderRadius: '8px', padding: '20px', boxShadow: 'var(--shadow-card)' }}>
                  <h3 style={{ fontSize: '14px', fontWeight: 800, color: 'var(--text-black)', marginBottom: '14px', textTransform: 'uppercase' }}>
                    3. Forma de Pagamento
                  </h3>

                  <div style={{ display: 'flex', gap: '10px', marginBottom: '16px' }}>
                    <button
                      type="button"
                      onClick={() => setPaymentMethod('PIX')}
                      style={{
                        flex: 1,
                        padding: '12px',
                        borderRadius: '4px',
                        border: paymentMethod === 'PIX' ? '2px solid var(--color-green)' : '1px solid var(--border-light)',
                        background: paymentMethod === 'PIX' ? '#F0FDF4' : '#FFFFFF',
                        color: paymentMethod === 'PIX' ? 'var(--color-green)' : 'var(--text-dark)',
                        fontWeight: 800,
                        fontSize: '13px',
                        cursor: 'pointer'
                      }}
                    >
                      Pix (10% de Desconto Imediato)
                    </button>
                    <button
                      type="button"
                      onClick={() => setPaymentMethod('CREDIT_CARD')}
                      style={{
                        flex: 1,
                        padding: '12px',
                        borderRadius: '4px',
                        border: paymentMethod === 'CREDIT_CARD' ? '2px solid var(--kabum-blue)' : '1px solid var(--border-light)',
                        background: paymentMethod === 'CREDIT_CARD' ? '#EBF4FC' : '#FFFFFF',
                        color: paymentMethod === 'CREDIT_CARD' ? 'var(--kabum-blue)' : 'var(--text-dark)',
                        fontWeight: 800,
                        fontSize: '13px',
                        cursor: 'pointer'
                      }}
                    >
                      Cartão de Crédito (até 12x)
                    </button>
                  </div>

                  {paymentMethod === 'PIX' ? (
                    <div
                      style={{
                        background: '#F0FDF4',
                        border: '1px solid #BBF7D0',
                        borderRadius: '4px',
                        padding: '14px',
                        textAlign: 'center',
                        color: 'var(--text-dark)',
                        fontSize: '12.5px'
                      }}
                    >
                      <strong style={{ color: 'var(--color-green)', fontSize: '13px', display: 'block', marginBottom: '4px' }}>
                        10% de Desconto Adicional no Pix
                      </strong>
                      O QR Code dinâmico e a chave Pix Copia e Cola serão gerados automaticamente na próxima tela pelo gateway homologado Asaas.
                    </div>
                  ) : (
                    <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '12px' }}>
                      <div style={{ gridColumn: '1 / -1' }}>
                        <label style={{ display: 'block', fontSize: '11.5px', color: 'var(--text-gray)', marginBottom: '4px', fontWeight: 600 }}>Número do Cartão *</label>
                        <input
                          type="text"
                          required
                          placeholder="0000 0000 0000 0000"
                          maxLength={19}
                          value={cardNumber}
                          onChange={(e) => setCardNumber(e.target.value)}
                          style={{ width: '100%', padding: '9px 12px', background: '#FFFFFF', border: '1px solid var(--border-light)', borderRadius: '4px', fontSize: '13px', outline: 'none' }}
                        />
                      </div>
                      <div style={{ gridColumn: '1 / -1' }}>
                        <label style={{ display: 'block', fontSize: '11.5px', color: 'var(--text-gray)', marginBottom: '4px', fontWeight: 600 }}>Nome Impresso no Cartão *</label>
                        <input
                          type="text"
                          required
                          placeholder="Como está no cartão"
                          value={cardHolder}
                          onChange={(e) => setCardHolder(e.target.value)}
                          style={{ width: '100%', padding: '9px 12px', background: '#FFFFFF', border: '1px solid var(--border-light)', borderRadius: '4px', fontSize: '13px', textTransform: 'uppercase', outline: 'none' }}
                        />
                      </div>
                      <div>
                        <label style={{ display: 'block', fontSize: '11.5px', color: 'var(--text-gray)', marginBottom: '4px', fontWeight: 600 }}>Validade (MM/AA) *</label>
                        <input
                          type="text"
                          required
                          placeholder="12/28"
                          maxLength={5}
                          value={cardExpiry}
                          onChange={(e) => setCardExpiry(e.target.value)}
                          style={{ width: '100%', padding: '9px 12px', background: '#FFFFFF', border: '1px solid var(--border-light)', borderRadius: '4px', fontSize: '13px', outline: 'none' }}
                        />
                      </div>
                      <div>
                        <label style={{ display: 'block', fontSize: '11.5px', color: 'var(--text-gray)', marginBottom: '4px', fontWeight: 600 }}>CVV *</label>
                        <input
                          type="text"
                          required
                          placeholder="123"
                          maxLength={4}
                          value={cardCvv}
                          onChange={(e) => setCardCvv(e.target.value)}
                          style={{ width: '100%', padding: '9px 12px', background: '#FFFFFF', border: '1px solid var(--border-light)', borderRadius: '4px', fontSize: '13px', outline: 'none' }}
                        />
                      </div>
                      <div style={{ gridColumn: '1 / -1' }}>
                        <label style={{ display: 'block', fontSize: '11.5px', color: 'var(--text-gray)', marginBottom: '4px', fontWeight: 600 }}>Parcelamento *</label>
                        <select
                          value={installments}
                          onChange={(e) => setInstallments(parseInt(e.target.value))}
                          style={{ width: '100%', padding: '9px 12px', background: '#FFFFFF', border: '1px solid var(--border-light)', borderRadius: '4px', fontSize: '13px', outline: 'none' }}
                        >
                          {[1, 2, 3, 4, 6, 8, 10, 12].map((n) => (
                            <option key={n} value={n}>
                              {n}x de R$ {(total / n).toFixed(2).replace('.', ',')} sem juros
                            </option>
                          ))}
                        </select>
                      </div>
                    </div>
                  )}
                </div>
              </div>

              {/* Sidebar Summary */}
              <div
                style={{
                  background: '#FFFFFF',
                  border: '1px solid var(--border-light)',
                  borderRadius: '8px',
                  padding: '20px',
                  boxShadow: 'var(--shadow-card)',
                  position: 'sticky',
                  top: '120px'
                }}
              >
                <h3 style={{ fontSize: '15px', fontWeight: 800, color: 'var(--text-black)', marginBottom: '14px' }}>
                  Resumo da Compra ({cartItems.length})
                </h3>

                <div style={{ maxHeight: '220px', overflowY: 'auto', marginBottom: '14px' }}>
                  {cartItems.map((it, idx) => (
                    <div key={idx} style={{ display: 'flex', gap: '8px', padding: '6px 0', borderBottom: '1px solid var(--border-subtle)' }}>
                      <img
                        src={it.image || '/imgs/products/cabo-furukawa-cat6.jpg'}
                        alt=""
                        style={{ width: '38px', height: '38px', objectFit: 'contain', background: '#FFFFFF', borderRadius: '4px', padding: '2px' }}
                      />
                      <div style={{ flex: 1, minWidth: 0, fontSize: '12px' }}>
                        <div style={{ color: 'var(--text-dark)', fontWeight: 600, whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>
                          {it.name}
                        </div>
                        <div style={{ color: 'var(--text-gray)', fontSize: '11px' }}>Qtd: {it.qty || 1}</div>
                      </div>
                      <div style={{ fontWeight: 700, color: 'var(--text-black)', fontSize: '12px' }}>
                        R$ {(it.price * (it.qty || 1)).toFixed(2).replace('.', ',')}
                      </div>
                    </div>
                  ))}
                </div>

                <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '12.5px', color: 'var(--text-gray)', marginBottom: '6px' }}>
                  <span>Subtotal:</span>
                  <span>R$ {subtotal.toFixed(2).replace('.', ',')}</span>
                </div>

                <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '12.5px', color: 'var(--text-gray)', marginBottom: '6px' }}>
                  <span>Frete:</span>
                  <span>{shippingCost === 0 ? <strong style={{ color: 'var(--color-green)' }}>Grátis</strong> : `R$ ${shippingCost.toFixed(2).replace('.', ',')}`}</span>
                </div>

                {paymentMethod === 'PIX' && (
                  <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '12.5px', color: 'var(--color-green)', fontWeight: 700, marginBottom: '6px' }}>
                    <span>Desconto Pix (10%):</span>
                    <span>- R$ {pixDiscount.toFixed(2).replace('.', ',')}</span>
                  </div>
                )}

                <div
                  style={{
                    display: 'flex',
                    justifyContent: 'space-between',
                    alignItems: 'baseline',
                    borderTop: '1px solid var(--border-subtle)',
                    paddingTop: '12px',
                    margin: '12px 0 16px'
                  }}
                >
                  <span style={{ fontSize: '14px', fontWeight: 800, color: 'var(--text-black)' }}>Total:</span>
                  <span style={{ fontSize: '20px', fontWeight: 900, color: 'var(--kabum-orange)' }}>
                    R$ {total.toFixed(2).replace('.', ',')}
                  </span>
                </div>

                <button
                  type="submit"
                  disabled={loading}
                  style={{
                    background: 'var(--kabum-orange)',
                    color: '#FFFFFF',
                    border: 'none',
                    padding: '12px 0',
                    fontSize: '13.5px',
                    fontWeight: 800,
                    width: '100%',
                    borderRadius: '4px',
                    cursor: 'pointer'
                  }}
                >
                  {loading ? 'Processando Gateway Asaas...' : 'CONFIRMAR E PAGAR'}
                </button>

                <div style={{ textAlign: 'center', marginTop: '10px', fontSize: '11px', color: 'var(--color-green)', fontWeight: 700 }}>
                  Transação Segura Criptografada SSL
                </div>
              </div>
            </form>
          )}
        </div>
      </main>

      <Footer />
    </>
  );
}
