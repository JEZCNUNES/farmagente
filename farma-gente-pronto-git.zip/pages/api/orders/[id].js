import prisma from '../../../lib/prisma';

export default async function handler(req, res) {
  const { id } = req.query;

  if (req.method !== 'GET') {
    return res.status(405).json({ error: 'Método não permitido' });
  }

  try {
    const order = await prisma.order.findFirst({
      where: {
        OR: [
          { id: String(id) },
          { orderNumber: String(id) },
        ],
      },
      include: {
        items: true,
      },
    });

    if (!order) {
      return res.status(404).json({ error: 'Pedido não encontrado.' });
    }

    return res.status(200).json(order);
  } catch (error) {
    console.error('[API ORDER] Erro ao consultar pedido:', error);
    return res.status(500).json({ error: 'Erro ao buscar pedido' });
  }
}
