import prisma from '../../../lib/prisma';
import { getOrCreateAsaasCustomer, createPixCharge, createCreditCardCharge } from '../../../lib/asaas';
import { sendOrderToTiny } from '../../../lib/tiny';

export default async function handler(req, res) {
  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Método não permitido' });
  }

  const {
    customer,
    shippingAddress,
    items,
    paymentMethod, // 'PIX' ou 'CREDIT_CARD'
    shippingMethod,
    shippingCost = 0,
    discount = 0,
    cardData,
    installments = 1,
  } = req.body;

  if (!customer?.name || !customer?.email || !customer?.cpf) {
    return res.status(400).json({ error: 'Dados do cliente incompletos.' });
  }

  if (!items || items.length === 0) {
    return res.status(400).json({ error: 'O carrinho está vazio.' });
  }

  try {
    // 1. Calcula totais do pedido
    const subtotal = items.reduce((acc, it) => acc + (parseFloat(it.price) * parseInt(it.quantity || it.qty || 1)), 0);
    let total = subtotal + parseFloat(shippingCost) - parseFloat(discount);

    // Pix tem 10% de desconto adicional
    if (paymentMethod === 'PIX') {
      const pixDiscount = subtotal * 0.10;
      total = Math.max(subtotal - pixDiscount + parseFloat(shippingCost) - parseFloat(discount), 1);
    }

    const orderNumber = `BR-${Math.floor(100000 + Math.random() * 900000)}`;

    // 2. Integração com Asaas
    let asaasCustomer;
    try {
      asaasCustomer = await getOrCreateAsaasCustomer({
        name: customer.name,
        email: customer.email,
        cpfCnpj: customer.cpf,
        phone: customer.phone,
        postalCode: shippingAddress?.cep,
        address: shippingAddress?.street,
        addressNumber: shippingAddress?.number,
      });
    } catch (err) {
      console.warn('[CHECKOUT] Aviso ao vincular cliente Asaas:', err.message);
    }

    let paymentResult = {};

    if (paymentMethod === 'PIX') {
      paymentResult = await createPixCharge({
        customerId: asaasCustomer?.id,
        value: total,
        description: `Pedido ${orderNumber} - BR Distribuidora`,
        externalReference: orderNumber,
      });
    } else if (paymentMethod === 'CREDIT_CARD') {
      if (!cardData?.cardNumber || !cardData?.holderName) {
        return res.status(400).json({ error: 'Dados do cartão de crédito obrigatórios.' });
      }

      paymentResult = await createCreditCardCharge({
        customerId: asaasCustomer?.id,
        value: total,
        description: `Pedido ${orderNumber} - BR Distribuidora`,
        externalReference: orderNumber,
        creditCard: cardData,
        creditCardHolderInfo: {
          name: customer.name,
          email: customer.email,
          cpfCnpj: customer.cpf,
          postalCode: shippingAddress?.cep || '13170000',
          addressNumber: shippingAddress?.number || '1',
          phone: customer.phone || '19999999999',
        },
        installmentCount: parseInt(installments, 10) || 1,
      });
    }

    // 3. Salva pedido no banco de dados PostgreSQL
    let savedOrder;
    try {
      savedOrder = await prisma.order.create({
        data: {
          orderNumber,
          customerName: customer.name,
          customerEmail: customer.email,
          customerPhone: customer.phone || '',
          customerCpf: customer.cpf,
          shippingCep: shippingAddress?.cep || '',
          shippingStreet: shippingAddress?.street || '',
          shippingNum: shippingAddress?.number || '',
          shippingComp: shippingAddress?.complement || '',
          shippingDist: shippingAddress?.district || '',
          shippingCity: shippingAddress?.city || '',
          shippingState: shippingAddress?.state || '',
          subtotal,
          shippingCost: parseFloat(shippingCost) || 0,
          shippingMethod: shippingMethod?.name || 'Padrão',
          discount: parseFloat(discount) || 0,
          total,
          paymentMethod,
          paymentStatus: paymentResult.status === 'CONFIRMED' ? 'PAID' : 'PENDING',
          asaasPaymentId: paymentResult.paymentId || null,
          pixQrCode: paymentResult.pixQrCode || null,
          pixCopiaECola: paymentResult.pixCopiaECola || null,
          cardLastFour: paymentResult.cardLastFour || null,
          installments: parseInt(installments, 10) || 1,
          items: {
            create: items.map((it) => ({
              name: it.name,
              price: parseFloat(it.price),
              quantity: parseInt(it.quantity || it.qty || 1, 10),
              image: it.image || '',
            })),
          },
        },
        include: { items: true },
      });
    } catch (dbErr) {
      console.warn('[CHECKOUT] DB create fallback (ex: conexão offline):', dbErr.message);
      savedOrder = {
        id: `mock-${orderNumber}`,
        orderNumber,
        customerName: customer.name,
        total,
        paymentStatus: 'PENDING',
        pixQrCode: paymentResult.pixQrCode,
        pixCopiaECola: paymentResult.pixCopiaECola,
      };
    }

    // 4. Integração Tiny ERP (respeita TINY_ENVIAR_PEDIDOS)
    sendOrderToTiny({
      customerName: customer.name,
      customerEmail: customer.email,
      customerPhone: customer.phone,
      customerCpf: customer.cpf,
      shippingCep: shippingAddress?.cep,
      shippingStreet: shippingAddress?.street,
      shippingNum: shippingAddress?.number,
      shippingComp: shippingAddress?.complement,
      shippingDist: shippingAddress?.district,
      shippingCity: shippingAddress?.city,
      shippingState: shippingAddress?.state,
      shippingCost: parseFloat(shippingCost) || 0,
      discount: parseFloat(discount) || 0,
      items,
    }).catch((tinyErr) => console.warn('[CHECKOUT] Tiny sync note:', tinyErr.message));

    return res.status(201).json({
      success: true,
      orderNumber,
      orderId: savedOrder.id,
      total,
      paymentMethod,
      paymentStatus: savedOrder.paymentStatus,
      pixQrCode: paymentResult.pixQrCode,
      pixCopiaECola: paymentResult.pixCopiaECola,
      expiresAt: paymentResult.expiresAt,
    });
  } catch (error) {
    console.error('[API CHECKOUT] Erro no processamento do pedido:', error);
    return res.status(500).json({
      error: error.message || 'Falha ao processar checkout.',
    });
  }
}
