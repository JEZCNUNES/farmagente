import prisma from '../../../lib/prisma';

export default async function handler(req, res) {
  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Método não permitido' });
  }

  // 1. Validação de Token de Acesso do Webhook (Segurança)
  const webhookTokenHeader = req.headers['asaas-access-token'];
  const expectedToken = process.env.ASAAS_WEBHOOK_TOKEN;

  if (expectedToken && webhookTokenHeader !== expectedToken) {
    console.warn('[WEBHOOK ASAAS] Token inválido recebido:', webhookTokenHeader);
    return res.status(401).json({ error: 'Acesso não autorizado: Token de webhook inválido' });
  }

  const { event, payment } = req.body;

  if (!event || !payment) {
    return res.status(400).json({ error: 'Payload incompleto' });
  }

  console.log(`[WEBHOOK ASAAS] Evento recebido: ${event} para cobrança: ${payment.id}`);

  try {
    // 2. Log de Auditoria
    await prisma.webhookLog.create({
      data: {
        event,
        payload: JSON.stringify(req.body),
        status: 'RECEIVED',
      },
    }).catch((e) => console.warn('[WEBHOOK ASAAS] Log DB warn:', e.message));

    // 3. Verifica se o evento é de confirmação de pagamento
    const paymentConfirmedEvents = [
      'PAYMENT_RECEIVED',
      'PAYMENT_CONFIRMED',
      'PAYMENT_RECEIVED_IN_CASH_UNDONE',
    ];

    if (!paymentConfirmedEvents.includes(event)) {
      return res.status(200).json({ received: true, action: 'IGNORED_EVENT' });
    }

    const externalRef = payment.externalReference;
    const asaasId = payment.id;

    // 4. Busca pedido correspondente
    const order = await prisma.order.findFirst({
      where: {
        OR: [
          { asaasPaymentId: asaasId },
          ...(externalRef ? [{ orderNumber: externalRef }] : []),
        ],
      },
    });

    if (!order) {
      console.warn(`[WEBHOOK ASAAS] Pedido não encontrado para pagamento ${asaasId}`);
      return res.status(200).json({ received: true, action: 'ORDER_NOT_FOUND' });
    }

    // 5. REGRA DE IDEMPOTÊNCIA: Se já estiver pago, ignora reprocessamento
    if (order.paymentStatus === 'PAID') {
      console.log(`[WEBHOOK ASAAS] Pedido ${order.orderNumber} já está marcado como pago. Idempotência garantida.`);
      return res.status(200).json({ received: true, action: 'ALREADY_PAID' });
    }

    // 6. Atualiza o status do pedido para 'PAID'
    await prisma.order.update({
      where: { id: order.id },
      data: {
        paymentStatus: 'PAID',
        notes: `Pagamento confirmado via Asaas webhook em ${new Date().toISOString()}`,
      },
    });

    console.log(`[WEBHOOK ASAAS] Pedido ${order.orderNumber} marcado como PAGO com sucesso.`);

    return res.status(200).json({ received: true, action: 'ORDER_UPDATED_TO_PAID' });
  } catch (error) {
    console.error('[WEBHOOK ASAAS] Erro ao processar:', error);
    return res.status(500).json({ error: 'Erro interno ao processar webhook' });
  }
}
