import prisma from '../../../lib/prisma';
import fs from 'fs';
import path from 'path';

function filterFallbackProducts(items, { q, category, brand, sort, take, skip }) {
  let filtered = [...items];

  if (category && category !== 'Todos') {
    const catLower = category.toLowerCase();
    filtered = filtered.filter((p) => (p.category || '').toLowerCase().includes(catLower));
  }

  if (brand && brand !== 'Todos') {
    const brandLower = brand.toLowerCase();
    filtered = filtered.filter((p) => (p.brand || '').toLowerCase().includes(brandLower));
  }

  if (q) {
    const qLower = q.toLowerCase();
    filtered = filtered.filter(
      (p) =>
        (p.name || '').toLowerCase().includes(qLower) ||
        (p.description || '').toLowerCase().includes(qLower) ||
        (p.brand || '').toLowerCase().includes(qLower) ||
        (p.sku || '').toLowerCase().includes(qLower)
    );
  }

  if (sort === 'price-asc') {
    filtered.sort((a, b) => (parseFloat(a.price) || 0) - (parseFloat(b.price) || 0));
  } else if (sort === 'price-desc') {
    filtered.sort((a, b) => (parseFloat(b.price) || 0) - (parseFloat(a.price) || 0));
  } else if (sort === 'name') {
    filtered.sort((a, b) => (a.name || '').localeCompare(b.name || ''));
  }

  const total = filtered.length;
  const paginated = filtered.slice(skip, skip + take);

  return {
    products: paginated,
    total,
  };
}

export default async function handler(req, res) {
  if (req.method !== 'GET') {
    return res.status(405).json({ error: 'Método não permitido' });
  }

  const { q, category, brand, sort, page = '1', limit = '50' } = req.query;
  const pageNum = parseInt(page, 10) || 1;
  const take = parseInt(limit, 10) || 50;
  const skip = (pageNum - 1) * take;

  try {
    const where = { active: true };

    if (category && category !== 'Todos') {
      where.category = { contains: category, mode: 'insensitive' };
    }

    if (brand && brand !== 'Todos') {
      where.brand = { contains: brand, mode: 'insensitive' };
    }

    if (q) {
      where.OR = [
        { name: { contains: q, mode: 'insensitive' } },
        { description: { contains: q, mode: 'insensitive' } },
        { brand: { contains: q, mode: 'insensitive' } },
        { sku: { contains: q, mode: 'insensitive' } },
      ];
    }

    let orderBy = { createdAt: 'desc' };
    if (sort === 'price-asc') orderBy = { price: 'asc' };
    if (sort === 'price-desc') orderBy = { price: 'desc' };
    if (sort === 'name') orderBy = { name: 'asc' };

    let [products, total] = await Promise.all([
      prisma.product.findMany({
        where,
        take,
        skip,
        orderBy,
      }),
      prisma.product.count({ where }),
    ]);

    // Se o banco ainda não tiver dados, carrega de clean_products.json com filtros
    if (products.length === 0) {
      const fallbackFile = path.join(process.cwd(), 'clean_products.json');
      if (fs.existsSync(fallbackFile)) {
        const raw = fs.readFileSync(fallbackFile, 'utf8');
        const fallbackItems = JSON.parse(raw);
        const { products: fProducts, total: fTotal } = filterFallbackProducts(fallbackItems, {
          q,
          category,
          brand,
          sort,
          take,
          skip,
        });

        return res.status(200).json({
          products: fProducts,
          total: fTotal,
          page: pageNum,
          pages: Math.ceil(fTotal / take) || 1,
          source: 'cache_fallback',
        });
      }
    }

    return res.status(200).json({
      products,
      total,
      page: pageNum,
      pages: Math.ceil(total / take) || 1,
      source: 'database',
    });
  } catch (error) {
    console.warn('[API PRODUCTS] Fallback para clean_products.json:', error.message);

    const fallbackFile = path.join(process.cwd(), 'clean_products.json');
    if (fs.existsSync(fallbackFile)) {
      const raw = fs.readFileSync(fallbackFile, 'utf8');
      const fallbackItems = JSON.parse(raw);
      const { products: fProducts, total: fTotal } = filterFallbackProducts(fallbackItems, {
        q,
        category,
        brand,
        sort,
        take,
        skip,
      });

      return res.status(200).json({
        products: fProducts,
        total: fTotal,
        page: pageNum,
        pages: Math.ceil(fTotal / take) || 1,
        source: 'cache_fallback',
      });
    }

    return res.status(500).json({ error: 'Falha ao buscar produtos' });
  }
}
