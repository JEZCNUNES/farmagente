import prisma from '../../../lib/prisma';
import fs from 'fs';
import path from 'path';

export default async function handler(req, res) {
  if (req.method !== 'GET') {
    return res.status(405).json({ error: 'Método não permitido' });
  }

  const { slug } = req.query;

  try {
    let product = await prisma.product.findUnique({
      where: { slug: String(slug) },
    });

    if (!product) {
      // Tenta fallback em clean_products.json
      const fallbackFile = path.join(process.cwd(), 'clean_products.json');
      if (fs.existsSync(fallbackFile)) {
        const raw = fs.readFileSync(fallbackFile, 'utf8');
        const fallbackItems = JSON.parse(raw);
        product = fallbackItems.find((p) => p.slug === slug || String(p.id) === slug);
      }
    }

    if (!product) {
      return res.status(404).json({ error: 'Produto não encontrado' });
    }

    return res.status(200).json(product);
  } catch (error) {
    console.error('[API PRODUCT DETAIL] Erro:', error);
    return res.status(500).json({ error: 'Erro ao buscar detalhes do produto' });
  }
}
