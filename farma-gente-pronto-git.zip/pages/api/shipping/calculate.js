import { calculateShipping } from '../../../lib/melhor-envio';

export default async function handler(req, res) {
  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Método não permitido' });
  }

  const { cep, subtotal = 0, items = [] } = req.body;

  if (!cep) {
    return res.status(400).json({ error: 'CEP é obrigatório.' });
  }

  try {
    const quotes = await calculateShipping({
      destinationCep: cep,
      subtotal: parseFloat(subtotal) || 0,
      items,
    });

    return res.status(200).json({
      success: true,
      destinationCep: cep,
      quotes,
    });
  } catch (error) {
    console.error('[API SHIPPING] Erro no cálculo de frete:', error);
    return res.status(500).json({
      error: error.message || 'Falha ao calcular frete com Melhor Envio',
    });
  }
}
