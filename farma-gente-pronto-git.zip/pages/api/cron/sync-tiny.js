import prisma from '../../../lib/prisma';
import {
  fetchTinyProductsPage,
  fetchTinyProductDetail,
  fetchTinyProductStock,
  slugify,
  categorize,
  detectBrand,
} from '../../../lib/tiny';

const delay = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

export default async function handler(req, res) {
  // Permite GET ou POST
  if (req.method !== 'GET' && req.method !== 'POST') {
    return res.status(405).json({ error: 'Método não permitido' });
  }

  // Verificação de token cron para segurança
  const cronSecret = process.env.CRON_SECRET || 'canal_cron_secret_key_2026';
  const providedAuth = req.headers.authorization || req.query.secret;

  if (providedAuth && providedAuth !== `Bearer ${cronSecret}` && providedAuth !== cronSecret) {
    return res.status(401).json({ error: 'Não autorizado' });
  }

  const token = process.env.TINY_API_TOKEN;
  if (!token) {
    return res.status(500).json({ error: 'TINY_API_TOKEN não configurado no .env' });
  }

  const startTime = new Date();
  let syncedCount = 0;
  let failedCount = 0;

  try {
    console.log('[CRON TINY] Iniciando sincronização de produtos e estoque...');

    // 1. Busca produtos do Tiny ERP
    const tinyItems = await fetchTinyProductsPage(token, 1);
    console.log(`[CRON TINY] ${tinyItems.length} produtos retornados da página 1 do Tiny ERP.`);

    for (const itemWrapper of tinyItems) {
      const p = itemWrapper.produto;
      if (!p || !p.id) continue;

      try {
        // Regra do PDF: máx ~30 req/min (2000ms delay entre chamadas de detalhe)
        await delay(2000);

        const stock = await fetchTinyProductStock(token, p.id);
        const price = parseFloat(p.preco) || 49.9;
        const oldPrice = price * 1.25;
        const slug = `${slugify(p.nome)}-${p.id}`;

        await prisma.product.upsert({
          where: { tinyId: String(p.id) },
          create: {
            tinyId: String(p.id),
            sku: p.codigo || null,
            gtin: p.gtin || null,
            name: p.nome,
            slug,
            price,
            oldPrice,
            discountPercent: 20,
            stock: Math.max(stock, 0),
            category: categorize(p.nome),
            brand: detectBrand(p.nome),
            freteGratis: price >= 199,
            image: 'https://http2.mlstatic.com/D_Q_NP_2X_903982-MLA99943261547_112025-E.webp',
            gallery: [],
            description: `${p.nome}. Produto original com nota fiscal e garantia de fábrica. Pronta entrega na Canal Distribuidora com envio imediato.`,
            active: p.situacao === 'A',
          },
          update: {
            name: p.nome,
            price,
            stock: Math.max(stock, 0),
            freteGratis: price >= 199,
            active: p.situacao === 'A',
          },
        });

        syncedCount++;
      } catch (prodErr) {
        console.warn(`[CRON TINY] Erro ao sincronizar produto ${p.id}:`, prodErr.message);
        failedCount++;
      }
    }

    // Grava log de sincronização no PostgreSQL
    await prisma.syncLog.create({
      data: {
        source: 'TINY',
        status: failedCount === 0 ? 'SUCCESS' : 'PARTIAL',
        itemsSynced: syncedCount,
        itemsFailed: failedCount,
        message: `Sincronizados ${syncedCount} itens, ${failedCount} falhas.`,
        startedAt: startTime,
        completedAt: new Date(),
      },
    }).catch((e) => console.warn('[CRON TINY] Log DB note:', e.message));

    return res.status(200).json({
      success: true,
      syncedCount,
      failedCount,
      durationSeconds: ((Date.now() - startTime.getTime()) / 1000).toFixed(1),
    });
  } catch (error) {
    console.error('[CRON TINY] Erro geral:', error);
    return res.status(500).json({ error: error.message });
  }
}
