import React, { useState, useEffect } from 'react';
import Head from 'next/head';
import Link from 'next/link';
import Header from '../components/Header';
import Footer from '../components/Footer';
import CartDrawer from '../components/CartDrawer';
import FarmaBot from '../components/FarmaBot';

export default function Home() {
  const [products, setProducts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [currentSlide, setCurrentSlide] = useState(0);

  const heroBanners = [
    {
      src: '/imgs/banners/banner-hero-1.png',
      alt: 'Tudo o que você precisa para cuidar de quem importa - Farma Gente'
    },
    {
      src: '/imgs/banners/banner-hero-2.png',
      alt: 'Sua farmácia na palma da mão - Drogaria Itajaí'
    },
    {
      src: '/imgs/banners/banner-hero-3.png',
      alt: 'Da farmácia para sua casa com praticidade - Farma Gente'
    }
  ];

  useEffect(() => {
    async function loadCatalog() {
      try {
        const res = await fetch('/api/products?limit=50');
        if (res.ok) {
          const data = await res.json();
          setProducts(Array.isArray(data) ? data : (data.products || []));
        } else {
          const fallback = await fetch('/clean_products.json');
          const data = await fallback.json();
          setProducts(Array.isArray(data) ? data : (data.products || []));
        }
      } catch (e) {
        console.warn('Erro ao carregar catálogo:', e);
      } finally {
        setLoading(false);
      }
    }
    loadCatalog();
  }, []);

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentSlide((prev) => (prev + 1) % heroBanners.length);
    }, 5000);
    return () => clearInterval(timer);
  }, [heroBanners.length]);

  const addToCart = (product) => {
    try {
      const cart = JSON.parse(localStorage.getItem('cm.cart') || '[]');
      const exist = cart.find((i) => String(i.id) === String(product.id));
      if (exist) {
        exist.qty = (exist.qty || 1) + 1;
      } else {
        cart.push({
          id: product.id,
          name: product.name,
          price: product.price,
          image: product.image,
          slug: product.slug,
          brand: product.brand,
          qty: 1
        });
      }
      localStorage.setItem('cm.cart', JSON.stringify(cart));
      window.dispatchEvent(new Event('storage'));
      setIsCartOpen(true);
    } catch (e) {}
  };

  const formatMoney = (val) =>
    new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(val || 0);

  const maisComprados = products.slice(0, 5);
  const dermocosmeticos = products.filter((p) => p.category === 'Dermocosméticos' || p.category === 'Linha Profissional').slice(0, 5);
  const vitaminas = products.filter((p) => p.category === 'Vitaminas' || p.category === 'Saúde & Aparelhos').slice(0, 5);

  return (
    <>
      <Head>
        <title>Rede Farma Gente | Drogaria Itajaí - Sua Farmácia Completa</title>
        <meta
          name="description"
          content="Compre medicamentos, dermocosméticos, vitaminas e produtos infantis com entrega rápida em até 1h em Itajaí e frete grátis."
        />
        <link rel="icon" href="/favicon.ico" />
      </Head>

      <Header onOpenCart={() => setIsCartOpen(true)} />

      <main className="container">
        {/* Quick Row / Flash Deal (Drogasil Reference) */}
        <div className="quick-row">
          <div className="flash-deal-pill">
            <span>⚡ Oferta Relâmpago</span>
            <span className="flash-timer">07h 59m 12s</span>
          </div>

          <Link href="/loja" className="quick-pill active">
            <span className="quick-pill-icon">🔥</span>
            <span>Mais Buscados</span>
          </Link>
          <Link href="/loja?cat=Medicamentos" className="quick-pill">
            <span className="quick-pill-icon">💊</span>
            <span>Medicamentos</span>
          </Link>
          <Link href="/loja?cat=Dermocosméticos" className="quick-pill">
            <span className="quick-pill-icon">✨</span>
            <span>Dermocosméticos</span>
          </Link>
          <Link href="/loja?cat=Vitaminas" className="quick-pill">
            <span className="quick-pill-icon">🌱</span>
            <span>Vitaminas</span>
          </Link>
          <Link href="/loja?cat=Mamãe & Bebê" className="quick-pill">
            <span className="quick-pill-icon">🍼</span>
            <span>Mamãe & Bebê</span>
          </Link>
          <Link href="/loja?ofertas=1" className="quick-pill">
            <span className="quick-pill-icon">🏷️</span>
            <span>Cupons Farma</span>
          </Link>
        </div>

        {/* Hero Slider Carousel */}
        <section className="hero-slider-section">
          <div className="hero-slider-container">
            {heroBanners.map((b, idx) => (
              <div key={idx} className={`hero-slide ${idx === currentSlide ? 'active' : ''}`}>
                <img src={b.src} alt={b.alt} />
              </div>
            ))}

            <button
              className="slider-btn prev"
              onClick={() => setCurrentSlide((prev) => (prev - 1 + heroBanners.length) % heroBanners.length)}
            >
              ❮
            </button>
            <button
              className="slider-btn next"
              onClick={() => setCurrentSlide((prev) => (prev + 1) % heroBanners.length)}
            >
              ❯
            </button>

            <div className="slider-dots">
              {heroBanners.map((_, idx) => (
                <span
                  key={idx}
                  className={`dot ${idx === currentSlide ? 'active' : ''}`}
                  onClick={() => setCurrentSlide(idx)}
                />
              ))}
            </div>
          </div>
        </section>

        {/* Benefits Bar (Drogasil Reference) */}
        <section className="benefits-section">
          <div className="benefits-grid">
            <div className="benefit-card">
              <div className="benefit-icon-wrapper">
                <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                  <circle cx="12" cy="12" r="10"></circle>
                  <polyline points="12 6 12 12 16 14"></polyline>
                </svg>
              </div>
              <div className="benefit-text">
                <strong>Entrega em 1h</strong>
                Receba com agilidade em Itajaí e Região!
              </div>
            </div>

            <div className="benefit-card">
              <div className="benefit-icon-wrapper">
                <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                  <path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"></path>
                </svg>
              </div>
              <div className="benefit-text">
                <strong>Pontos & Descontos</strong>
                Ganhe cashback nas compras no Clube.
              </div>
            </div>

            <div className="benefit-card">
              <div className="benefit-icon-wrapper">
                <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                  <path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"></path>
                  <polyline points="9 22 9 12 15 12 15 22"></polyline>
                </svg>
              </div>
              <div className="benefit-text">
                <strong>Retire em 30min</strong>
                Retirada grátis em nossa loja física.
              </div>
            </div>

            <div className="benefit-card">
              <div className="benefit-icon-wrapper">
                <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                  <line x1="19" y1="5" x2="5" y2="19"></line>
                  <circle cx="6.5" cy="6.5" r="2.5"></circle>
                  <circle cx="17.5" cy="17.5" r="2.5"></circle>
                </svg>
              </div>
              <div className="benefit-text">
                <strong>Até 70% OFF</strong>
                Descontos especiais em genéricos.
              </div>
            </div>

            <div className="benefit-card">
              <div className="benefit-icon-wrapper">
                <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                  <path d="M22 12h-4l-3 9L9 3l-3 9H2"></path>
                </svg>
              </div>
              <div className="benefit-text">
                <strong>Atenção Farmacêutica</strong>
                Aferição de pressão e suporte online.
              </div>
            </div>
          </div>
        </section>

        {/* Shelf 1: Mais Comprados */}
        <section className="shelf-section">
          <div className="shelf-header">
            <h2 className="shelf-title">Mais Comprados</h2>
            <div className="shelf-controls">
              <Link href="/loja" style={{ color: '#009B9D', fontWeight: 700, fontSize: 14, marginRight: 12 }}>
                Ver todos ➔
              </Link>
            </div>
          </div>
          <div className="shelf-grid">
            {maisComprados.map((p) => (
              <article key={p.id} className="product-card">
                {p.discountPercent > 0 && <div className="product-card-discount">-{p.discountPercent}%</div>}
                {p.badge && <div className="product-card-badge">{p.badge}</div>}

                <Link href={`/produto/${p.slug}`} className="product-card-img-wrap">
                  <img src={p.image} alt={p.name} loading="lazy" />
                </Link>

                <div className="product-brand">{p.brand || 'Farma Gente'}</div>
                <Link href={`/produto/${p.slug}`}>
                  <h3 className="product-title">{p.name}</h3>
                </Link>

                <div className="product-rating">
                  ★★★★★ <span>({p.reviews || 48})</span>
                </div>

                <div className="product-price-box">
                  <div className="price-details">
                    {p.oldPrice && <div className="price-old">{formatMoney(p.oldPrice)}</div>}
                    <div className="price-current">{formatMoney(p.price)}</div>
                    <div className="price-pix">no Pix: <strong>{formatMoney(p.price * 0.95)}</strong></div>
                  </div>

                  <button className="btn-add-cart-circle" title="Adicionar à Cesta" onClick={() => addToCart(p)}>
                    +
                  </button>
                </div>
              </article>
            ))}
          </div>
        </section>

        {/* Strip Banner 1 */}
        <section className="strip-banner-section">
          <div className="strip-banner-container">
            <img src="/imgs/banners/banner-strip-1.png" alt="Cuidar de quem importa" />
          </div>
        </section>

        {/* Visual Categories (Drogasil Reference) */}
        <section className="visual-categories-section">
          <div className="shelf-header">
            <h2 className="shelf-title">Cuidados que você merece</h2>
          </div>
          <div className="visual-categories-grid">
            <Link href="/loja?cat=Dermocosméticos" className="visual-category-card">
              <img src="/imgs/categories/cuidados-pele.jpg" alt="Cuidados com a Pele" />
            </Link>
            <Link href="/loja?cat=Mamãe & Bebê" className="visual-category-card">
              <img src="/imgs/categories/mamae-bebe.jpg" alt="Mamãe & Bebê" />
            </Link>
            <Link href="/loja?cat=Medicamentos" className="visual-category-card">
              <img src="/imgs/categories/cuidados-inverno.jpg" alt="Cuidados no Inverno" />
            </Link>
            <Link href="/loja?cat=Perfumaria" className="visual-category-card">
              <img src="/imgs/categories/perfumes.jpg" alt="Perfumaria" />
            </Link>
            <Link href="/loja?cat=Dermocosméticos" className="visual-category-card">
              <img src="/imgs/categories/protecao-solar.jpg" alt="Proteção Solar" />
            </Link>
            <Link href="/loja?cat=Dermocosméticos" className="visual-category-card">
              <img src="/imgs/categories/produtos-asiaticos.jpg" alt="Produtos Asiáticos e K-Beauty" />
            </Link>
          </div>
        </section>

        {/* Shelf 2: Dermocosméticos e Cabelos */}
        <section className="shelf-section">
          <div className="shelf-header">
            <h2 className="shelf-title">Conheça produtos da linha profissional</h2>
            <div className="shelf-controls">
              <Link href="/loja?cat=Linha Profissional" style={{ color: '#009B9D', fontWeight: 700, fontSize: 14, marginRight: 12 }}>
                Ver todos ➔
              </Link>
            </div>
          </div>
          <div className="shelf-grid">
            {dermocosmeticos.map((p) => (
              <article key={p.id} className="product-card">
                {p.discountPercent > 0 && <div className="product-card-discount">-{p.discountPercent}%</div>}
                <Link href={`/produto/${p.slug}`} className="product-card-img-wrap">
                  <img src={p.image} alt={p.name} loading="lazy" />
                </Link>
                <div className="product-brand">{p.brand}</div>
                <Link href={`/produto/${p.slug}`}><h3 className="product-title">{p.name}</h3></Link>
                <div className="product-rating">★★★★★ <span>({p.reviews})</span></div>
                <div className="product-price-box">
                  <div className="price-details">
                    {p.oldPrice && <div className="price-old">{formatMoney(p.oldPrice)}</div>}
                    <div className="price-current">{formatMoney(p.price)}</div>
                    <div className="price-pix">no Pix: <strong>{formatMoney(p.price * 0.95)}</strong></div>
                  </div>
                  <button className="btn-add-cart-circle" onClick={() => addToCart(p)}>+</button>
                </div>
              </article>
            ))}
          </div>
        </section>

        {/* Prescription Callout */}
        <section className="prescription-callout">
          <div className="prescription-content">
            <h3>Precisa de remédio com receita médica? 📋</h3>
            <p>Envie sua receita pelo site ou WhatsApp. Nossos farmacêuticos conferem a dosagem, separam os medicamentos e entregam rapidinho no seu endereço em Itajaí!</p>
          </div>
          <a
            href="https://wa.me/5547999887766?text=Ol%C3%A1%20Dra.%20Sol!%20Gostaria%20de%20enviar%20uma%20receita%20m%C3%A9dica."
            target="_blank"
            rel="noreferrer"
            className="prescription-btn"
          >
            Enviar Receita no WhatsApp ➔
          </a>
        </section>

        {/* Strip Banner 2 */}
        <section className="strip-banner-section">
          <div className="strip-banner-container">
            <img src="/imgs/banners/banner-strip-2.png" alt="Sua farmácia na palma da mão" />
          </div>
        </section>
      </main>

      <Footer />
      <FarmaBot />
      <CartDrawer isOpen={isCartOpen} onClose={() => setIsCartOpen(false)} />
    </>
  );
}
