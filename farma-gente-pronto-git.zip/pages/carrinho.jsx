import React, { useState, useEffect } from 'react';
import Head from 'next/head';
import Link from 'next/link';
import Header from '../components/Header';
import Footer from '../components/Footer';
import BRBot from '../components/BRBot';

export default function Carrinho() {
  const [items, setItems] = useState([]);
  const [coupon, setCoupon] = useState('');
  const [discountPercent, setDiscountPercent] = useState(0);

  const loadCart = () => {
    try {
      const saved = JSON.parse(localStorage.getItem('cm.cart') || '[]');
      setItems(saved);
      const appliedCoupon = localStorage.getItem('cm.coupon');
      if (appliedCoupon === 'BR10' || appliedCoupon === 'FOX10' || appliedCoupon === 'PRIMEIRACOMPRA') {
        setDiscountPercent(10);
      }
    } catch (e) {
      setItems([]);
    }
  };

  useEffect(() => {
    loadCart();
  }, []);

  const updateQuantity = (idx, delta) => {
    const updated = [...items];
    const newQty = (updated[idx].qty || 1) + delta;
    if (newQty <= 0) {
      updated.splice(idx, 1);
    } else {
      updated[idx].qty = newQty;
    }
    setItems(updated);
    localStorage.setItem('cm.cart', JSON.stringify(updated));
    window.dispatchEvent(new Event('cart-updated'));
  };

  const removeItem = (idx) => {
    const updated = [...items];
    updated.splice(idx, 1);
    setItems(updated);
    localStorage.setItem('cm.cart', JSON.stringify(updated));
    window.dispatchEvent(new Event('cart-updated'));
  };

  const applyCoupon = () => {
    const clean = coupon.trim().toUpperCase();
    if (clean === 'BR10' || clean === 'FOX10' || clean === 'PRIMEIRACOMPRA') {
      localStorage.setItem('cm.coupon', clean);
      setDiscountPercent(10);
      alert(`Cupom ${clean} aplicado! 10% de desconto.`);
    } else {
      alert('Cupom inválido. Tente BR10 ou FOX10.');
    }
  };

  const subtotal = items.reduce((acc, it) => acc + (parseFloat(it.price) * (it.qty || 1)), 0);
  const discountVal = (subtotal * discountPercent) / 100;
  const total = Math.max(subtotal - discountVal, 0);
  const pixPrice = (total * 0.90).toFixed(2).replace('.', ',');

  const freeShippingThreshold = 199;
  const remainingForFreeShipping = Math.max(freeShippingThreshold - total, 0);
  const freeShippingPercent = Math.min((total / freeShippingThreshold) * 100, 100);

  return (
    <>
      <Head>
        <title>Meu Carrinho de Compras | BR Distribuidora Oficial</title>
        <link rel="icon" type="image/png" href="/imgs/br/logo-color.png" />
      </Head>

      <Header />

      <main style={{ padding: '24px 0 60px', minHeight: '75vh' }}>
        <div className="container">
          <div style={{ fontSize: '12px', color: 'var(--text-gray)', marginBottom: '16px' }}>
            <Link href="/" style={{ color: 'var(--kabum-blue)' }}>Home</Link> &gt; <span>Carrinho de Compras</span>
          </div>

          <h1 style={{ fontSize: '20px', fontWeight: 800, color: 'var(--text-black)', marginBottom: '20px' }}>
            Meu Carrinho ({items.length} {items.length === 1 ? 'item' : 'itens'})
          </h1>

          {items.length === 0 ? (
            <div
              style={{
                background: '#FFFFFF',
                border: '1px solid var(--border-light)',
                borderRadius: '8px',
                padding: '60px 20px',
                textAlign: 'center',
                boxShadow: 'var(--shadow-card)'
              }}
            >
              <img
                src="/imgs/br/mascote-tablet.png"
                alt="Carrinho Vazio"
                style={{ width: '120px', margin: '0 auto 16px', opacity: 0.9 }}
              />
              <h2 style={{ color: 'var(--text-black)', fontSize: '18px', marginBottom: '8px', fontWeight: 800 }}>
                Seu carrinho está vazio
              </h2>
              <p style={{ color: 'var(--text-gray)', fontSize: '13px', marginBottom: '20px' }}>
                Conheça nossa linha de cabeamento estruturado, CFTV 4K, nobreaks e fibra óptica.
              </p>
              <Link
                href="/loja"
                style={{
                  background: 'var(--kabum-orange)',
                  color: '#FFFFFF',
                  padding: '10px 24px',
                  borderRadius: '4px',
                  fontWeight: 800,
                  fontSize: '13px',
                  display: 'inline-block'
                }}
              >
                Explorar Catálogo
              </Link>
            </div>
          ) : (
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 360px', gap: '24px', alignItems: 'flex-start' }}>
              <div>
                {/* Free Shipping Alert */}
                <div
                  style={{
                    background: '#FFFFFF',
                    border: '1px solid var(--border-light)',
                    borderRadius: '8px',
                    padding: '14px 18px',
                    marginBottom: '16px',
                    boxShadow: 'var(--shadow-card)'
                  }}
                >
                  <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '12.5px', marginBottom: '8px' }}>
                    <span style={{ color: 'var(--text-dark)' }}>
                      {remainingForFreeShipping > 0 ? (
                        <>Faltam <strong style={{ color: 'var(--kabum-orange)' }}>R$ {remainingForFreeShipping.toFixed(2).replace('.', ',')}</strong> para <strong>Frete Grátis</strong></>
                      ) : (
                        <strong style={{ color: 'var(--color-green)' }}>Parabéns! Você atingiu o Frete Grátis!</strong>
                      )}
                    </span>
                    <span style={{ color: 'var(--text-gray)', fontWeight: 700 }}>{Math.round(freeShippingPercent)}%</span>
                  </div>
                  <div style={{ height: '6px', background: '#E2E8F0', borderRadius: '3px', overflow: 'hidden' }}>
                    <div style={{ height: '100%', width: `${freeShippingPercent}%`, background: 'var(--color-green)', transition: 'width 0.3s' }}></div>
                  </div>
                </div>

                {/* Items List */}
                <div style={{ display: 'flex', flexDirection: 'column', gap: '12px' }}>
                  {items.map((it, idx) => (
                    <div
                      key={idx}
                      style={{
                        background: '#FFFFFF',
                        border: '1px solid var(--border-light)',
                        borderRadius: '8px',
                        padding: '16px',
                        display: 'flex',
                        alignItems: 'center',
                        gap: '16px',
                        boxShadow: 'var(--shadow-card)'
                      }}
                    >
                      <img
                        src={it.image || '/imgs/products/cabo-furukawa-cat6.jpg'}
                        alt={it.name}
                        style={{ width: '70px', height: '70px', objectFit: 'contain', background: '#FFFFFF', borderRadius: '4px', padding: '4px' }}
                        onError={(e) => {
                          e.currentTarget.onerror = null;
                          e.currentTarget.src = '/imgs/products/cabo-furukawa-cat6.jpg';
                        }}
                      />
                      <div style={{ flex: 1, minWidth: 0 }}>
                        <Link href={`/produto/${it.slug || it.id}`}>
                          <h3 style={{ fontSize: '13px', fontWeight: 600, color: 'var(--text-black)', marginBottom: '4px', lineHeight: 1.35 }}>
                            {it.name}
                          </h3>
                        </Link>
                        <div style={{ fontSize: '12px', color: 'var(--text-gray)' }}>
                          Unitário: R$ {(parseFloat(it.price) || 0).toFixed(2).replace('.', ',')}
                        </div>
                      </div>

                      <div style={{ display: 'flex', alignItems: 'center', border: '1px solid var(--border-light)', borderRadius: '4px' }}>
                        <button
                          onClick={() => updateQuantity(idx, -1)}
                          style={{ background: '#F8F9FA', border: 'none', padding: '6px 10px', cursor: 'pointer', fontWeight: 800 }}
                        >
                          -
                        </button>
                        <span style={{ fontWeight: 800, padding: '0 10px', color: 'var(--text-black)', fontSize: '13px' }}>{it.qty || 1}</span>
                        <button
                          onClick={() => updateQuantity(idx, 1)}
                          style={{ background: '#F8F9FA', border: 'none', padding: '6px 10px', cursor: 'pointer', fontWeight: 800 }}
                        >
                          +
                        </button>
                      </div>

                      <div style={{ textAlign: 'right', minWidth: '95px' }}>
                        <div style={{ fontSize: '15px', fontWeight: 900, color: 'var(--kabum-orange)' }}>
                          R$ {(it.price * (it.qty || 1)).toFixed(2).replace('.', ',')}
                        </div>
                        <button
                          onClick={() => removeItem(idx)}
                          style={{ color: 'var(--text-gray)', fontSize: '11px', textDecoration: 'underline', marginTop: '4px', background: 'transparent', border: 'none', cursor: 'pointer' }}
                        >
                          Remover
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Order Summary */}
              <div
                style={{
                  background: '#FFFFFF',
                  border: '1px solid var(--border-light)',
                  borderRadius: '8px',
                  padding: '20px',
                  boxShadow: 'var(--shadow-card)',
                  position: 'sticky',
                  top: '120px'
                }}
              >
                <h3 style={{ fontSize: '16px', fontWeight: 800, color: 'var(--text-black)', marginBottom: '16px' }}>
                  Resumo do Pedido
                </h3>

                <div style={{ display: 'flex', gap: '6px', marginBottom: '16px' }}>
                  <input
                    type="text"
                    placeholder="CUPOM (ex: BR10)"
                    value={coupon}
                    onChange={(e) => setCoupon(e.target.value)}
                    style={{
                      flex: 1,
                      padding: '8px 10px',
                      background: '#FFFFFF',
                      border: '1px solid var(--border-light)',
                      borderRadius: '4px',
                      color: 'var(--text-dark)',
                      fontSize: '12px',
                      textTransform: 'uppercase',
                      outline: 'none'
                    }}
                  />
                  <button
                    onClick={applyCoupon}
                    style={{
                      background: '#F1F5F9',
                      border: '1px solid var(--border-light)',
                      color: 'var(--text-dark)',
                      padding: '0 14px',
                      borderRadius: '4px',
                      fontSize: '12px',
                      fontWeight: 700,
                      cursor: 'pointer'
                    }}
                  >
                    Aplicar
                  </button>
                </div>

                <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '12.5px', color: 'var(--text-gray)', marginBottom: '8px' }}>
                  <span>Subtotal:</span>
                  <span>R$ {subtotal.toFixed(2).replace('.', ',')}</span>
                </div>

                {discountPercent > 0 && (
                  <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '12.5px', color: 'var(--color-green)', marginBottom: '8px' }}>
                    <span>Desconto ({discountPercent}%):</span>
                    <span>- R$ {discountVal.toFixed(2).replace('.', ',')}</span>
                  </div>
                )}

                <div
                  style={{
                    display: 'flex',
                    justifyContent: 'space-between',
                    alignItems: 'baseline',
                    borderTop: '1px solid var(--border-subtle)',
                    paddingTop: '12px',
                    margin: '12px 0'
                  }}
                >
                  <span style={{ fontSize: '15px', fontWeight: 800, color: 'var(--text-black)' }}>Total:</span>
                  <span style={{ fontSize: '20px', fontWeight: 900, color: 'var(--kabum-orange)' }}>
                    R$ {total.toFixed(2).replace('.', ',')}
                  </span>
                </div>

                <div
                  style={{
                    background: '#DCFCE7',
                    border: '1px solid #BBF7D0',
                    borderRadius: '4px',
                    padding: '8px 10px',
                    marginBottom: '16px',
                    textAlign: 'center'
                  }}
                >
                  <span style={{ fontSize: '11.5px', color: '#166534', fontWeight: 700 }}>
                    No Pix com 10% OFF: R$ {pixPrice}
                  </span>
                </div>

                <Link
                  href="/checkout"
                  style={{
                    background: 'var(--kabum-orange)',
                    color: '#FFFFFF',
                    padding: '12px 0',
                    fontSize: '13.5px',
                    fontWeight: 800,
                    width: '100%',
                    textAlign: 'center',
                    borderRadius: '4px',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    gap: '6px'
                  }}
                >
                  <span>FECHAR PEDIDO</span>
                  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5">
                    <polyline points="9 18 15 12 9 6"></polyline>
                  </svg>
                </Link>
              </div>
            </div>
          )}
        </div>
      </main>

      <Footer />
      <BRBot />
    </>
  );
}
