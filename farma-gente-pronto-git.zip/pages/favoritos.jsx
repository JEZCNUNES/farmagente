import React, { useState, useEffect } from 'react';
import Head from 'next/head';
import Link from 'next/link';
import Header from '../components/Header';
import Footer from '../components/Footer';
import CartDrawer from '../components/CartDrawer';
import BRBot from '../components/BRBot';

export default function Favoritos() {
  const [favorites, setFavorites] = useState([]);
  const [isCartOpen, setIsCartOpen] = useState(false);

  useEffect(() => {
    try {
      const favs = JSON.parse(localStorage.getItem('cm.favorites') || '[]');
      setFavorites(favs);
    } catch (e) {
      setFavorites([]);
    }
  }, []);

  const removeFavorite = (slug) => {
    const updated = favorites.filter((f) => f.slug !== slug);
    setFavorites(updated);
    localStorage.setItem('cm.favorites', JSON.stringify(updated));
  };

  const addToCart = (product) => {
    try {
      const cart = JSON.parse(localStorage.getItem('cm.cart') || '[]');
      const existing = cart.find((i) => i.slug === product.slug);
      if (existing) {
        existing.qty = (existing.qty || 1) + 1;
      } else {
        cart.push({
          id: product.id,
          slug: product.slug,
          name: product.name,
          price: product.price,
          image: product.image,
          qty: 1,
        });
      }
      localStorage.setItem('cm.cart', JSON.stringify(cart));
      window.dispatchEvent(new Event('cart-updated'));
      setIsCartOpen(true);
    } catch (e) {
      console.error(e);
    }
  };

  return (
    <>
      <Head>
        <title>Meus Favoritos | BR Distribuidora — Telecom, Redes & CFTV</title>
        <link rel="icon" type="image/png" href="/imgs/br/logo-color.png" />
      </Head>

      <Header onOpenCart={() => setIsCartOpen(true)} />

      <main style={{ padding: '24px 0 60px', minHeight: '75vh' }}>
        <div className="container">
          <div style={{ fontSize: '12px', color: 'var(--text-gray)', marginBottom: '16px' }}>
            <Link href="/" style={{ color: 'var(--kabum-blue)' }}>Home</Link> &gt; <span>Itens Favoritos</span>
          </div>

          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '24px', flexWrap: 'wrap', gap: '14px' }}>
            <div>
              <h1 style={{ fontSize: '20px', fontWeight: 800, color: 'var(--text-black)', margin: 0 }}>
                Meus Favoritos ({favorites.length})
              </h1>
              <p style={{ color: 'var(--text-gray)', fontSize: '12.5px', margin: '4px 0 0' }}>
                Equipamentos salvos para cotação e acompanhamento de estoque.
              </p>
            </div>
            {favorites.length > 0 && (
              <Link
                href="/loja"
                style={{
                  background: '#FFFFFF',
                  border: '1px solid var(--border-light)',
                  padding: '8px 16px',
                  borderRadius: '4px',
                  fontSize: '12px',
                  fontWeight: 700,
                  color: 'var(--text-dark)'
                }}
              >
                Continuar Comprando
              </Link>
            )}
          </div>

          {favorites.length === 0 ? (
            <div
              style={{
                textAlign: 'center',
                padding: '60px 20px',
                background: '#FFFFFF',
                borderRadius: '8px',
                border: '1px solid var(--border-light)',
                maxWidth: '600px',
                margin: '0 auto',
                boxShadow: 'var(--shadow-card)'
              }}
            >
              <img
                src="/imgs/br/mascote-front.png"
                alt="Sem favoritos"
                style={{ width: '110px', margin: '0 auto 16px' }}
              />
              <h2 style={{ fontSize: '16px', fontWeight: 800, color: 'var(--text-black)', marginBottom: '6px' }}>
                Sua lista de favoritos está vazia
              </h2>
              <p style={{ color: 'var(--text-gray)', fontSize: '13px', marginBottom: '20px', lineHeight: 1.5 }}>
                Explore nossos cabos de rede Furukawa e CommScope, nobreaks industriais, switches PoE e câmeras CFTV 4K.
                Clique no ícone de coração nos produtos para salvá-los aqui.
              </p>
              <Link
                href="/loja"
                style={{
                  background: 'var(--kabum-orange)',
                  color: '#FFFFFF',
                  padding: '10px 24px',
                  borderRadius: '4px',
                  fontWeight: 800,
                  fontSize: '13px',
                  display: 'inline-block'
                }}
              >
                Ver Catálogo Técnico
              </Link>
            </div>
          ) : (
            <div className="kabum-product-grid">
              {favorites.map((p, index) => {
                const pixPrice = (p.price * 0.90).toFixed(2).replace('.', ',');
                const installmentVal = (p.price / 10).toFixed(2).replace('.', ',');

                return (
                  <div key={p.slug || index} className="kabum-card">
                    <div>
                      <div className="kabum-card-top">
                        <span className="kabum-rating-pill">
                          <svg viewBox="0 0 24 24">
                            <polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"></polygon>
                          </svg>
                          4.8
                        </span>

                        <button
                          onClick={() => removeFavorite(p.slug)}
                          className="kabum-card-action-btn"
                          title="Remover dos favoritos"
                        >
                          ✕
                        </button>
                      </div>

                      <Link href={`/produto/${p.slug}`} className="kabum-card-img-wrap">
                        <img
                          src={p.image || '/imgs/products/cabo-furukawa-cat6.jpg'}
                          alt={p.name}
                          className="kabum-card-img"
                          onError={(e) => {
                            e.currentTarget.onerror = null;
                            e.currentTarget.src = '/imgs/products/cabo-furukawa-cat6.jpg';
                          }}
                        />
                      </Link>

                      <div className="kabum-card-badges">
                        <span className="badge-prime-ninja">PRONTA ENTREGA</span>
                      </div>

                      <Link href={`/produto/${p.slug}`}>
                        <h3 className="kabum-card-title" title={p.name}>
                          {p.name}
                        </h3>
                      </Link>
                    </div>

                    <div className="kabum-pricing-block">
                      <div className="kabum-main-price-row">
                        <span className="kabum-pix-price">
                          R$ {pixPrice}
                        </span>
                        <span className="kabum-discount-tag">
                          -10%
                        </span>
                      </div>

                      <div className="kabum-installment-text">
                        No PIX ou 10x de R$ {installmentVal}
                      </div>

                      <button
                        onClick={() => addToCart(p)}
                        className="kabum-buy-btn"
                      >
                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5">
                          <circle cx="9" cy="21" r="1"></circle>
                          <circle cx="20" cy="21" r="1"></circle>
                          <path d="M1 1h4l2.68 13.39a2 2 0 0 0 2 1.61h9.72a2 2 0 0 0 2-1.61L23 6H6"></path>
                        </svg>
                        COMPRAR
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      </main>

      <Footer />
      <CartDrawer isOpen={isCartOpen} onClose={() => setIsCartOpen(false)} />
      <BRBot />
    </>
  );
}
