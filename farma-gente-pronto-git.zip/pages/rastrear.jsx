import React, { useState, useEffect } from 'react';
import Head from 'next/head';
import Link from 'next/link';
import { useRouter } from 'next/router';
import Header from '../components/Header';
import Footer from '../components/Footer';
import BRBot from '../components/BRBot';

export default function Rastrear() {
  const router = useRouter();
  const [orderQuery, setOrderQuery] = useState('');
  const [order, setOrder] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const fetchOrder = async (id) => {
    if (!id) return;
    setLoading(true);
    setError('');
    setOrder(null);

    try {
      const res = await fetch(`/api/orders/${encodeURIComponent(id)}`);
      if (res.ok) {
        const data = await res.json();
        setOrder(data);
      } else {
        const localOrders = JSON.parse(localStorage.getItem('cm.orders') || '[]');
        const found = localOrders.find((o) => String(o.id) === id || o.orderNumber === id);
        if (found) {
          setOrder(found);
        } else {
          setError('Pedido não encontrado no sistema. Verifique o código (ex: BR-123456) ou fale com nossa equipe via WhatsApp.');
        }
      }
    } catch (e) {
      setError('Erro de conexão ao buscar o pedido.');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (router.query.id) {
      setOrderQuery(router.query.id);
      fetchOrder(router.query.id);
    }
  }, [router.query.id]);

  const handleSearch = (e) => {
    e.preventDefault();
    if (orderQuery.trim()) {
      fetchOrder(orderQuery.trim());
    }
  };

  return (
    <>
      <Head>
        <title>Rastreamento de Pedidos | BR Distribuidora Oficial</title>
        <link rel="icon" type="image/png" href="/imgs/br/logo-color.png" />
      </Head>

      <Header />

      <main style={{ padding: '30px 0 60px', minHeight: '75vh' }}>
        <div className="container" style={{ maxWidth: '720px' }}>
          <div style={{ textAlign: 'center', marginBottom: '28px' }}>
            <h1 style={{ fontSize: '22px', fontWeight: 900, color: 'var(--text-black)', marginBottom: '6px' }}>
              Rastreamento de Encomendas
            </h1>
            <p style={{ color: 'var(--text-gray)', fontSize: '13px' }}>
              Acompanhe o status do seu pedido desde a separação até a entrega no endereço cadastrado.
            </p>
          </div>

          {/* Search Card */}
          <div
            style={{
              background: '#FFFFFF',
              border: '1px solid var(--border-light)',
              borderRadius: '8px',
              padding: '24px',
              marginBottom: '24px',
              boxShadow: 'var(--shadow-card)'
            }}
          >
            <form onSubmit={handleSearch} style={{ display: 'flex', gap: '8px' }}>
              <input
                type="text"
                placeholder="Digite o número do pedido (ex: BR-123456)"
                value={orderQuery}
                onChange={(e) => setOrderQuery(e.target.value)}
                style={{
                  flex: 1,
                  padding: '10px 14px',
                  background: '#FFFFFF',
                  border: '1px solid var(--border-light)',
                  borderRadius: '4px',
                  fontSize: '13px',
                  color: 'var(--text-dark)',
                  outline: 'none'
                }}
              />
              <button
                type="submit"
                disabled={loading}
                style={{
                  background: 'var(--kabum-orange)',
                  color: '#FFFFFF',
                  border: 'none',
                  padding: '0 20px',
                  borderRadius: '4px',
                  fontWeight: 800,
                  fontSize: '13px',
                  cursor: 'pointer'
                }}
              >
                {loading ? 'Buscando...' : 'Rastrear'}
              </button>
            </form>

            {error && (
              <div style={{ marginTop: '12px', color: 'var(--color-red)', fontSize: '12px', textAlign: 'center' }}>
                {error}
              </div>
            )}
          </div>

          {/* Result Card */}
          {order && (
            <div
              style={{
                background: '#FFFFFF',
                border: '1px solid var(--border-light)',
                borderRadius: '8px',
                padding: '24px',
                boxShadow: 'var(--shadow-card)'
              }}
            >
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', borderBottom: '1px solid var(--border-subtle)', paddingBottom: '14px', marginBottom: '20px' }}>
                <div>
                  <h3 style={{ color: 'var(--text-black)', fontSize: '15px', fontWeight: 800, margin: 0 }}>
                    Pedido #{order.orderNumber}
                  </h3>
                  <span style={{ fontSize: '11.5px', color: 'var(--text-gray)' }}>
                    Data da compra: {new Date(order.createdAt).toLocaleDateString('pt-BR')}
                  </span>
                </div>
                <span
                  style={{
                    background: order.paymentStatus === 'PAID' ? '#DCFCE7' : '#FEF3C7',
                    color: order.paymentStatus === 'PAID' ? '#166534' : '#92400E',
                    border: `1px solid ${order.paymentStatus === 'PAID' ? '#BBF7D0' : '#FDE68A'}`,
                    padding: '3px 10px',
                    borderRadius: '4px',
                    fontSize: '11px',
                    fontWeight: 800
                  }}
                >
                  {order.paymentStatus === 'PAID' ? 'PAGAMENTO APROVADO' : 'AGUARDANDO PAGAMENTO'}
                </span>
              </div>

              {/* Progress Timeline */}
              <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: '8px', textAlign: 'center', marginBottom: '24px' }}>
                <div style={{ padding: '10px 4px', background: '#F0FDF4', borderRadius: '4px', border: '1px solid var(--color-green)' }}>
                  <div style={{ fontSize: '13px', fontWeight: 800, color: 'var(--color-green)', marginBottom: '2px' }}>1</div>
                  <strong style={{ fontSize: '11px', color: 'var(--color-green)', display: 'block' }}>Realizado</strong>
                </div>
                <div style={{ padding: '10px 4px', background: order.paymentStatus === 'PAID' ? '#F0FDF4' : '#F8F9FA', borderRadius: '4px', border: order.paymentStatus === 'PAID' ? '1px solid var(--color-green)' : '1px solid var(--border-light)' }}>
                  <div style={{ fontSize: '13px', fontWeight: 800, color: order.paymentStatus === 'PAID' ? 'var(--color-green)' : 'var(--text-gray)', marginBottom: '2px' }}>2</div>
                  <strong style={{ fontSize: '11px', color: order.paymentStatus === 'PAID' ? 'var(--color-green)' : 'var(--text-gray)', display: 'block' }}>Pagamento</strong>
                </div>
                <div style={{ padding: '10px 4px', background: '#F8F9FA', borderRadius: '4px', border: '1px solid var(--border-light)' }}>
                  <div style={{ fontSize: '13px', fontWeight: 800, color: 'var(--text-gray)', marginBottom: '2px' }}>3</div>
                  <strong style={{ fontSize: '11px', color: 'var(--text-gray)', display: 'block' }}>Separação</strong>
                </div>
                <div style={{ padding: '10px 4px', background: '#F8F9FA', borderRadius: '4px', border: '1px solid var(--border-light)' }}>
                  <div style={{ fontSize: '13px', fontWeight: 800, color: 'var(--text-gray)', marginBottom: '2px' }}>4</div>
                  <strong style={{ fontSize: '11px', color: 'var(--text-gray)', display: 'block' }}>Transporte</strong>
                </div>
              </div>

              {/* Order Info */}
              <div style={{ fontSize: '12.5px', color: 'var(--text-dark)', lineHeight: 1.8 }}>
                <div><strong>Destinatário:</strong> {order.customerName}</div>
                <div><strong>Cidade / UF:</strong> {order.shippingCity}/{order.shippingState}</div>
                <div><strong>Modalidade de Frete:</strong> {order.shippingMethod || 'Sedex / Jadlog Expresso'}</div>
                <div><strong>Valor Total:</strong> <span style={{ color: 'var(--kabum-orange)', fontWeight: 800 }}>R$ {(order.total || 0).toFixed(2).replace('.', ',')}</span></div>
              </div>
            </div>
          )}
        </div>
      </main>

      <Footer />
      <BRBot />
    </>
  );
}
