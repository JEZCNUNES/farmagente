import React, { useState } from 'react';
import Head from 'next/head';
import Link from 'next/link';
import Header from '../components/Header';
import Footer from '../components/Footer';
import BRBot from '../components/BRBot';

export default function Admin() {
  const [syncLoading, setSyncLoading] = useState(false);
  const [syncResult, setSyncResult] = useState(null);

  const triggerTinySync = async () => {
    setSyncLoading(true);
    setSyncResult(null);
    try {
      const res = await fetch('/api/cron/sync-tiny');
      const data = await res.json();
      setSyncResult(data);
    } catch (e) {
      setSyncResult({ error: e.message });
    } finally {
      setSyncLoading(false);
    }
  };

  const categories = [
    'Cabeamento Estruturado',
    'Conectorização & Keystones',
    'Patch Cords & Patch Panels',
    'Nobreaks & Baterias',
    'Infraestrutura Seca',
    'Caixas de Comando & Quadros',
    'Rotuladores & Identificação',
    'CFTV & Segurança Eletrônica',
    'Controle de Acesso Facial',
    'Fibra Óptica & FTTx',
    'Proteção Elétrica & DPS'
  ];

  return (
    <>
      <Head>
        <title>Painel de Operações & Retaguarda | BR Distribuidora</title>
        <link rel="icon" type="image/png" href="/imgs/br/logo-color.png" />
      </Head>

      <Header />

      <main style={{ padding: '30px 0 60px', minHeight: '75vh' }}>
        <div className="container" style={{ maxWidth: '960px' }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '24px', flexWrap: 'wrap', gap: '14px' }}>
            <div>
              <div style={{ display: 'inline-block', background: '#EBF4FC', border: '1px solid var(--kabum-blue)', padding: '2px 8px', borderRadius: '4px', fontSize: '11px', color: 'var(--kabum-blue)', fontWeight: 800, marginBottom: '6px' }}>
                CENTRO DE COMANDO B2B
              </div>
              <h1 style={{ fontSize: '22px', fontWeight: 900, color: 'var(--text-black)', margin: 0 }}>
                Retaguarda BR Distribuidora
              </h1>
              <p style={{ margin: '2px 0 0', color: 'var(--text-gray)', fontSize: '13px' }}>
                Gestão de estoque via Tiny ERP, Gateway Asaas (Pix/Cartão) e Cotações de Frete
              </p>
            </div>
            <span style={{ background: '#DCFCE7', color: '#166534', border: '1px solid #BBF7D0', fontWeight: 800, padding: '6px 14px', borderRadius: '4px', fontSize: '12px' }}>
              Sistemas 100% Operacionais
            </span>
          </div>

          {/* Cards de Status das Integrações */}
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(280px, 1fr))', gap: '16px', marginBottom: '28px' }}>
            {/* Tiny ERP Card */}
            <div
              style={{
                background: '#FFFFFF',
                padding: '20px',
                borderRadius: '8px',
                border: '1px solid var(--border-light)',
                boxShadow: 'var(--shadow-card)'
              }}
            >
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '8px' }}>
                <strong style={{ fontSize: '14px', color: 'var(--text-black)' }}>
                  Tiny ERP v3
                </strong>
                <span style={{ fontSize: '10.5px', fontWeight: 800, color: 'var(--color-green)', background: '#DCFCE7', padding: '2px 6px', borderRadius: '3px' }}>
                  CONECTADO
                </span>
              </div>
              <p style={{ fontSize: '12px', color: 'var(--text-gray)', margin: '0 0 14px', lineHeight: 1.5 }}>
                Sincroniza estoque e preços das bobinas e equipamentos em tempo real. Roda a cada 15 min.
              </p>
              <button
                onClick={triggerTinySync}
                disabled={syncLoading}
                style={{
                  width: '100%',
                  background: 'var(--kabum-blue)',
                  color: '#FFFFFF',
                  border: 'none',
                  padding: '9px',
                  borderRadius: '4px',
                  fontWeight: 800,
                  fontSize: '12px',
                  cursor: 'pointer'
                }}
              >
                {syncLoading ? 'Sincronizando com Tiny...' : 'Forçar Sincronização Agora'}
              </button>
            </div>

            {/* Melhor Envio Card */}
            <div
              style={{
                background: '#FFFFFF',
                padding: '20px',
                borderRadius: '8px',
                border: '1px solid var(--border-light)',
                boxShadow: 'var(--shadow-card)'
              }}
            >
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '8px' }}>
                <strong style={{ fontSize: '14px', color: 'var(--text-black)' }}>
                  Melhor Envio & Fretes
                </strong>
                <span style={{ fontSize: '10.5px', fontWeight: 800, color: 'var(--color-green)', background: '#DCFCE7', padding: '2px 6px', borderRadius: '3px' }}>
                  ATIVO
                </span>
              </div>
              <p style={{ fontSize: '12px', color: 'var(--text-gray)', margin: '0 0 10px', lineHeight: 1.5 }}>
                Hub de Saída: <strong>Campinas / Sumaré SP</strong>. Cotações automáticas de Sedex, Jadlog e transportadoras de carga pesada.
              </p>
              <div style={{ fontSize: '12px', color: 'var(--kabum-blue)', fontWeight: 700 }}>
                Frete Grátis acima de R$ 199,00
              </div>
            </div>

            {/* Asaas Card */}
            <div
              style={{
                background: '#FFFFFF',
                padding: '20px',
                borderRadius: '8px',
                border: '1px solid var(--border-light)',
                boxShadow: 'var(--shadow-card)'
              }}
            >
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '8px' }}>
                <strong style={{ fontSize: '14px', color: 'var(--text-black)' }}>
                  Asaas Pagamentos
                </strong>
                <span style={{ fontSize: '10.5px', fontWeight: 800, color: 'var(--color-green)', background: '#DCFCE7', padding: '2px 6px', borderRadius: '3px' }}>
                  HOMOLOGADO
                </span>
              </div>
              <p style={{ fontSize: '12px', color: 'var(--text-gray)', margin: '0 0 10px', lineHeight: 1.5 }}>
                Pix QR Code dinâmico com 10% OFF automático. Cartão de Crédito até 12x com validação anti-fraude.
              </p>
              <div style={{ fontSize: '12px', color: 'var(--kabum-orange)', fontWeight: 700 }}>
                Webhook Idempotente Ativo
              </div>
            </div>
          </div>

          {/* Resultado da Sincronização */}
          {syncResult && (
            <div
              style={{
                background: syncResult.error ? '#FEE2E2' : '#F0FDF4',
                border: syncResult.error ? '1px solid #FCA5A5' : '1px solid #BBF7D0',
                padding: '16px',
                borderRadius: '6px',
                marginBottom: '28px'
              }}
            >
              <h4 style={{ margin: '0 0 6px', color: syncResult.error ? '#991B1B' : '#166534', fontWeight: 800, fontSize: '13px' }}>
                {syncResult.error ? 'Falha na Sincronização' : 'Sincronização Concluída com Sucesso!'}
              </h4>
              <pre style={{ fontSize: '11.5px', margin: 0, fontFamily: 'monospace', color: 'var(--text-dark)', overflowX: 'auto' }}>
                {JSON.stringify(syncResult, null, 2)}
              </pre>
            </div>
          )}

          {/* 11 Segmentos Técnicos no Catálogo */}
          <div
            style={{
              background: '#FFFFFF',
              borderRadius: '8px',
              border: '1px solid var(--border-light)',
              padding: '24px',
              marginBottom: '28px',
              boxShadow: 'var(--shadow-card)'
            }}
          >
            <h3 style={{ fontSize: '15px', fontWeight: 800, color: 'var(--text-black)', marginBottom: '6px' }}>
              Divisões de Engenharia & Segmentos Ativos
            </h3>
            <p style={{ color: 'var(--text-gray)', fontSize: '12.5px', marginBottom: '16px' }}>
              Catálogo segmentado conforme o escopo oficial da BR Distribuidora:
            </p>

            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(220px, 1fr))', gap: '8px' }}>
              {categories.map((cat, i) => (
                <div
                  key={i}
                  style={{
                    display: 'flex',
                    alignItems: 'center',
                    gap: '8px',
                    padding: '8px 12px',
                    background: '#F8F9FA',
                    border: '1px solid var(--border-subtle)',
                    borderRadius: '4px',
                    fontSize: '12px'
                  }}
                >
                  <span style={{ color: 'var(--kabum-blue)', fontWeight: 800 }}>
                    {String(i + 1).padStart(2, '0')}
                  </span>
                  <span style={{ color: 'var(--text-dark)', fontWeight: 600 }}>
                    {cat}
                  </span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </main>

      <Footer />
      <BRBot />
    </>
  );
}
