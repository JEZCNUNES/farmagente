import React, { useState } from 'react';
import Head from 'next/head';
import Header from '../components/Header';
import Footer from '../components/Footer';
import BRBot from '../components/BRBot';

export default function Suporte() {
  const [openFaq, setOpenFaq] = useState(null);
  const [b2bName, setB2bName] = useState('');
  const [b2bCnpj, setB2bCnpj] = useState('');
  const [b2bPhone, setB2bPhone] = useState('');
  const [b2bItems, setB2bItems] = useState('');

  const faqs = [
    {
      q: 'Como funciona o faturamento via boleto bancário para empresas (CNPJ)?',
      a: 'Para empresas, integradores e provedores cadastrados, realizamos análise de crédito rápida (em até 2 horas). Faturamos com condições especiais de 28, 28/35/42 ou até 60 dias conforme o volume da lista de materiais.',
    },
    {
      q: 'Vocês emitem Nota Fiscal Eletrônica com destaque de impostos (ICMS/ST)?',
      a: 'Sim! 100% das vendas da BR Distribuidora acompanham Nota Fiscal Eletrônica (NF-e) emitida de acordo com o regime tributário da sua empresa, com chave de acesso XML e DANFE enviados por e-mail.',
    },
    {
      q: 'Como é feito o envio de materiais pesados (bobinas de cabo, nobreaks de 10kVA e eletrocalhas)?',
      a: 'Possuímos convênios com as principais transportadoras de carga pesada e fracionada do Brasil, além de frota dedicada para a região metropolitana de Campinas e São Paulo. Itens leves seguem via Sedex ou Jadlog.',
    },
    {
      q: 'Os cabos de rede e equipamentos possuem homologação oficial da Anatel?',
      a: 'Sim. Todos os produtos das marcas Furukawa, CommScope, Legrand, Hikvision, Intelbras e SMS são rigorosamente certificados e homologados com selo Anatel e normas ABNT vigentes.',
    },
    {
      q: 'Vocês auxiliam na elaboração de listas de materiais para projetos de TI e CFTV?',
      a: 'Com certeza! Nosso time conta com engenheiros de telecomunicações e especialistas em infraestrutura de TI prontos para dimensionar a quantidade de portas, DIOs, nobreaks e analíticos de câmeras para sua proposta técnica.',
    },
  ];

  const handleB2bSubmit = (e) => {
    e.preventDefault();
    const msg = `Olá, BR Distribuidora! Solicitação de cotação corporativa:%0A%0A*Empresa:* ${encodeURIComponent(b2bName)}%0A*CNPJ:* ${encodeURIComponent(b2bCnpj)}%0A*Telefone:* ${encodeURIComponent(b2bPhone)}%0A%0A*Lista de Materiais Necessária:*%0A${encodeURIComponent(b2bItems)}`;
    window.open(`https://wa.me/5519992893859?text=${msg}`, '_blank');
  };

  return (
    <>
      <Head>
        <title>Central B2B & Suporte de Engenharia | BR Distribuidora</title>
        <meta
          name="description"
          content="Canal direto de atendimento para provedores de internet, instaladores e empresas. Cotações corporativas e suporte técnico especializado."
        />
        <link rel="icon" type="image/png" href="/imgs/br/logo-color.png" />
      </Head>

      <Header />

      <main style={{ padding: '30px 0 60px', minHeight: '80vh' }}>
        <div className="container" style={{ maxWidth: '860px' }}>
          {/* Hero Banner */}
          <div
            style={{
              background: 'var(--br-blue)',
              borderRadius: '8px',
              padding: '36px 30px',
              color: '#FFFFFF',
              textAlign: 'center',
              marginBottom: '32px',
              boxShadow: 'var(--shadow-card)'
            }}
          >
            <span
              style={{
                fontSize: '11px',
                fontWeight: 800,
                textTransform: 'uppercase',
                letterSpacing: '0.5px',
                color: '#FFFFFF',
                background: 'rgba(255, 255, 255, 0.15)',
                padding: '4px 12px',
                borderRadius: '4px',
                display: 'inline-block',
                marginBottom: '12px'
              }}
            >
              Atendimento Corporativo & Engenharia
            </span>
            <h1 style={{ fontSize: '24px', fontWeight: 900, marginBottom: '8px' }}>
              Suporte Técnico Especializado BR
            </h1>
            <p style={{ color: '#D6E4F0', fontSize: '13.5px', maxWidth: '600px', margin: '0 auto 20px', lineHeight: 1.5 }}>
              Cotações em lote, homologações de projeto de rede e faturamento direto com nossa equipe de engenharia e televendas.
            </p>
            <a
              href="https://wa.me/5519992893859?text=Ol%C3%A1%2C%20BR%20Distribuidora!%20Gostaria%20de%20falar%20com%20um%20especialista%20de%20engenharia."
              target="_blank"
              rel="noreferrer"
              style={{
                background: 'var(--kabum-orange)',
                color: '#FFFFFF',
                padding: '12px 24px',
                borderRadius: '4px',
                fontWeight: 800,
                fontSize: '13px',
                display: 'inline-flex',
                alignItems: 'center',
                gap: '8px'
              }}
            >
              <span>Falar no WhatsApp Oficial: (19) 99289-3859</span>
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5">
                <polyline points="9 18 15 12 9 6"></polyline>
              </svg>
            </a>
          </div>

          {/* B2B Quotation Form */}
          <div
            style={{
              background: '#FFFFFF',
              border: '1px solid var(--border-light)',
              borderRadius: '8px',
              padding: '28px',
              marginBottom: '32px',
              boxShadow: 'var(--shadow-card)'
            }}
          >
            <h2 style={{ fontSize: '16px', fontWeight: 800, color: 'var(--text-black)', marginBottom: '6px' }}>
              Solicitar Cotação B2B / Lista de Materiais
            </h2>
            <p style={{ color: 'var(--text-gray)', fontSize: '12.5px', marginBottom: '20px' }}>
              Preencha o formulário abaixo com os itens necessários para o seu projeto. Retornamos rapidamente com o orçamento formal:
            </p>

            <form onSubmit={handleB2bSubmit} style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '12px' }}>
              <div style={{ gridColumn: '1 / -1' }}>
                <label style={{ display: 'block', fontSize: '11.5px', color: 'var(--text-gray)', marginBottom: '4px', fontWeight: 600 }}>
                  Razão Social ou Nome Fantasia *
                </label>
                <input
                  type="text"
                  required
                  placeholder="Nome da sua empresa"
                  value={b2bName}
                  onChange={(e) => setB2bName(e.target.value)}
                  style={{ width: '100%', padding: '9px 12px', background: '#FFFFFF', border: '1px solid var(--border-light)', borderRadius: '4px', fontSize: '13px', outline: 'none' }}
                />
              </div>

              <div>
                <label style={{ display: 'block', fontSize: '11.5px', color: 'var(--text-gray)', marginBottom: '4px', fontWeight: 600 }}>
                  CNPJ *
                </label>
                <input
                  type="text"
                  required
                  placeholder="00.000.000/0000-00"
                  value={b2bCnpj}
                  onChange={(e) => setB2bCnpj(e.target.value)}
                  style={{ width: '100%', padding: '9px 12px', background: '#FFFFFF', border: '1px solid var(--border-light)', borderRadius: '4px', fontSize: '13px', outline: 'none' }}
                />
              </div>

              <div>
                <label style={{ display: 'block', fontSize: '11.5px', color: 'var(--text-gray)', marginBottom: '4px', fontWeight: 600 }}>
                  Telefone / WhatsApp com DDD *
                </label>
                <input
                  type="text"
                  required
                  placeholder="(00) 00000-0000"
                  value={b2bPhone}
                  onChange={(e) => setB2bPhone(e.target.value)}
                  style={{ width: '100%', padding: '9px 12px', background: '#FFFFFF', border: '1px solid var(--border-light)', borderRadius: '4px', fontSize: '13px', outline: 'none' }}
                />
              </div>

              <div style={{ gridColumn: '1 / -1' }}>
                <label style={{ display: 'block', fontSize: '11.5px', color: 'var(--text-gray)', marginBottom: '4px', fontWeight: 600 }}>
                  Lista de Materiais e Quantidades Desejadas *
                </label>
                <textarea
                  required
                  rows={4}
                  placeholder="Ex:&#10;- 10 Caixas Cabo CAT6 Furukawa Azul 305m&#10;- 2 Patch Panels 24 Portas CAT6&#10;- 1 Nobreak Vertiv Liebert On-Line 3kVA&#10;- 4 Câmeras Hikvision 4K ColorVu"
                  value={b2bItems}
                  onChange={(e) => setB2bItems(e.target.value)}
                  style={{ width: '100%', padding: '10px 12px', background: '#FFFFFF', border: '1px solid var(--border-light)', borderRadius: '4px', fontSize: '13px', outline: 'none', resize: 'vertical' }}
                />
              </div>

              <div style={{ gridColumn: '1 / -1' }}>
                <button
                  type="submit"
                  style={{
                    width: '100%',
                    background: 'var(--kabum-orange)',
                    color: '#FFFFFF',
                    border: 'none',
                    padding: '12px 0',
                    borderRadius: '4px',
                    fontWeight: 800,
                    fontSize: '13px',
                    cursor: 'pointer'
                  }}
                >
                  Enviar Lista para Cotação Imediata
                </button>
              </div>
            </form>
          </div>

          {/* FAQs */}
          <div style={{ background: '#FFFFFF', border: '1px solid var(--border-light)', borderRadius: '8px', padding: '28px', boxShadow: 'var(--shadow-card)' }}>
            <h2 style={{ fontSize: '16px', fontWeight: 800, color: 'var(--text-black)', marginBottom: '16px' }}>
              Perguntas Frequentes (FAQ)
            </h2>

            <div style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>
              {faqs.map((faq, i) => (
                <div
                  key={i}
                  style={{
                    border: '1px solid var(--border-subtle)',
                    borderRadius: '4px',
                    overflow: 'hidden'
                  }}
                >
                  <button
                    onClick={() => setOpenFaq(openFaq === i ? null : i)}
                    style={{
                      width: '100%',
                      padding: '12px 16px',
                      background: '#F8F9FA',
                      display: 'flex',
                      justifyContent: 'space-between',
                      alignItems: 'center',
                      color: 'var(--text-black)',
                      fontWeight: 700,
                      fontSize: '13px',
                      textAlign: 'left',
                      border: 'none',
                      cursor: 'pointer'
                    }}
                  >
                    <span>{faq.q}</span>
                    <span style={{ color: 'var(--kabum-orange)', fontSize: '16px', fontWeight: 800 }}>
                      {openFaq === i ? '−' : '+'}
                    </span>
                  </button>

                  {openFaq === i && (
                    <div style={{ padding: '14px 16px', background: '#FFFFFF', color: 'var(--text-dark)', fontSize: '12.5px', lineHeight: 1.6 }}>
                      {faq.a}
                    </div>
                  )}
                </div>
              ))}
            </div>
          </div>
        </div>
      </main>

      <Footer />
      <BRBot />
    </>
  );
}
