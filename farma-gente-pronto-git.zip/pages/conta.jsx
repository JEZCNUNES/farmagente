import React, { useState, useEffect } from 'react';
import Head from 'next/head';
import Link from 'next/link';
import Header from '../components/Header';
import Footer from '../components/Footer';
import BRBot from '../components/BRBot';

export default function Conta() {
  const [user, setUser] = useState(null);
  const [isRegister, setIsRegister] = useState(false);
  const [loading, setLoading] = useState(true);

  // Form states
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [cpf, setCpf] = useState('');
  const [phone, setPhone] = useState('');
  const [termsAccepted, setTermsAccepted] = useState(false);
  const [msg, setMsg] = useState('');
  const [error, setError] = useState('');

  const checkAuth = async () => {
    const token = localStorage.getItem('cm.auth_token');
    if (!token) {
      setLoading(false);
      return;
    }

    try {
      const res = await fetch('/api/auth/me', {
        headers: { Authorization: `Bearer ${token}` },
      });
      if (res.ok) {
        const data = await res.json();
        setUser(data);
      } else {
        localStorage.removeItem('cm.auth_token');
        setUser(null);
      }
    } catch (e) {
      console.warn('Auth check error:', e);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    checkAuth();
  }, []);

  const handleLogin = async (e) => {
    e.preventDefault();
    setError('');
    setMsg('');

    try {
      const res = await fetch('/api/auth/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email, password }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Erro ao autenticar');

      localStorage.setItem('cm.auth_token', data.token);
      setUser(data.user);
      setMsg('Login efetuado com sucesso!');
      checkAuth();
    } catch (err) {
      setError(err.message);
    }
  };

  const handleRegister = async (e) => {
    e.preventDefault();
    setError('');
    setMsg('');

    if (!termsAccepted) {
      setError('É necessário aceitar os Termos e a Política de Privacidade (LGPD).');
      return;
    }

    try {
      const res = await fetch('/api/auth/register', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ name, email, password, cpf, phone, termsAccepted }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Erro ao cadastrar');

      localStorage.setItem('cm.auth_token', data.token);
      setUser(data.user);
      setMsg('Conta criada com sucesso!');
      checkAuth();
    } catch (err) {
      setError(err.message);
    }
  };

  const handleLogout = () => {
    localStorage.removeItem('cm.auth_token');
    setUser(null);
  };

  const handleDeleteAccount = async () => {
    if (!confirm('Atenção: Deseja realmente excluir permanentemente sua conta e todos os dados associados? Esta ação não pode ser desfeita.')) {
      return;
    }

    const token = localStorage.getItem('cm.auth_token');
    try {
      const res = await fetch('/api/auth/delete', {
        method: 'DELETE',
        headers: { Authorization: `Bearer ${token}` },
      });
      const data = await res.json();
      if (res.ok) {
        alert(data.message || 'Conta excluída com sucesso.');
        handleLogout();
      } else {
        alert(data.error || 'Falha ao excluir conta.');
      }
    } catch (e) {
      alert('Erro de conexão ao solicitar exclusão.');
    }
  };

  return (
    <>
      <Head>
        <title>Minha Conta | BR Distribuidora Oficial</title>
        <link rel="icon" type="image/png" href="/imgs/br/logo-color.png" />
      </Head>

      <Header />

      <main style={{ padding: '30px 0 60px', minHeight: '75vh' }}>
        <div className="container" style={{ maxWidth: '640px' }}>
          <div style={{ fontSize: '12px', color: 'var(--text-gray)', marginBottom: '16px' }}>
            <Link href="/" style={{ color: 'var(--kabum-blue)' }}>Home</Link> &gt; <span>Minha Conta</span>
          </div>

          {loading ? (
            <div style={{ textAlign: 'center', padding: '60px', color: 'var(--text-gray)' }}>
              Carregando dados da conta...
            </div>
          ) : user ? (
            /* Painel do Usuário Logado */
            <div
              style={{
                background: '#FFFFFF',
                borderRadius: '8px',
                border: '1px solid var(--border-light)',
                padding: '28px',
                boxShadow: 'var(--shadow-card)'
              }}
            >
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', borderBottom: '1px solid var(--border-subtle)', paddingBottom: '18px', marginBottom: '22px' }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: '14px' }}>
                  <img
                    src="/imgs/br/mascote-front.png"
                    alt="BR Mascot"
                    style={{ width: '48px', height: '48px', objectFit: 'contain', background: '#F8F9FA', borderRadius: '50%', padding: '4px', border: '1px solid var(--border-light)' }}
                  />
                  <div>
                    <h1 style={{ fontSize: '18px', fontWeight: 800, color: 'var(--text-black)', margin: 0 }}>
                      Olá, {user.name}!
                    </h1>
                    <p style={{ margin: '2px 0 0', color: 'var(--text-gray)', fontSize: '12px' }}>
                      {user.email} {user.cpf && `· Doc: ${user.cpf}`}
                    </p>
                  </div>
                </div>
                <button
                  onClick={handleLogout}
                  style={{
                    padding: '6px 14px',
                    background: '#F1F5F9',
                    border: '1px solid var(--border-light)',
                    borderRadius: '4px',
                    fontWeight: 700,
                    fontSize: '12px',
                    cursor: 'pointer',
                    color: 'var(--text-dark)'
                  }}
                >
                  Sair
                </button>
              </div>

              {/* Pedidos do Cliente */}
              <div style={{ marginBottom: '28px' }}>
                <h3 style={{ fontSize: '14px', fontWeight: 800, color: 'var(--text-black)', marginBottom: '14px', textTransform: 'uppercase' }}>
                  Meus Pedidos & Cotações
                </h3>

                {user.orders && user.orders.length > 0 ? (
                  <div style={{ display: 'flex', flexDirection: 'column', gap: '10px' }}>
                    {user.orders.map((o) => (
                      <div
                        key={o.id}
                        style={{
                          display: 'flex',
                          justifyContent: 'space-between',
                          alignItems: 'center',
                          padding: '14px',
                          border: '1px solid var(--border-light)',
                          borderRadius: '6px',
                          background: '#F8F9FA'
                        }}
                      >
                        <div>
                          <strong style={{ color: 'var(--text-black)', fontSize: '13px' }}>Pedido #{o.orderNumber}</strong>
                          <div style={{ fontSize: '11.5px', color: 'var(--text-gray)', marginTop: '2px' }}>
                            {new Date(o.createdAt).toLocaleDateString('pt-BR')} · <span style={{ color: 'var(--kabum-orange)', fontWeight: 800 }}>R$ {o.total.toFixed(2).replace('.', ',')}</span>
                          </div>
                        </div>
                        <Link
                          href={`/rastrear?id=${o.orderNumber}`}
                          style={{
                            background: '#FFFFFF',
                            border: '1px solid var(--border-light)',
                            padding: '6px 12px',
                            borderRadius: '4px',
                            fontSize: '11.5px',
                            fontWeight: 700,
                            color: 'var(--text-dark)'
                          }}
                        >
                          Rastrear
                        </Link>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div style={{ background: '#F8F9FA', padding: '20px', borderRadius: '6px', textAlign: 'center', border: '1px solid var(--border-subtle)' }}>
                    <p style={{ fontSize: '12.5px', color: 'var(--text-gray)', margin: '0 0 12px' }}>
                      Nenhum pedido faturado ainda.
                    </p>
                    <Link
                      href="/loja"
                      style={{
                        background: 'var(--kabum-orange)',
                        color: '#FFF',
                        padding: '8px 16px',
                        borderRadius: '4px',
                        fontWeight: 800,
                        fontSize: '12px',
                        display: 'inline-block'
                      }}
                    >
                      Ir para o Catálogo Técnico
                    </Link>
                  </div>
                )}
              </div>

              {/* Seção LGPD */}
              <div
                style={{
                  background: '#F8F9FA',
                  border: '1px solid var(--border-light)',
                  borderRadius: '6px',
                  padding: '16px'
                }}
              >
                <h4 style={{ fontSize: '13px', fontWeight: 800, color: 'var(--text-black)', margin: '0 0 6px' }}>
                  Privacidade & Proteção de Dados (LGPD)
                </h4>
                <p style={{ fontSize: '12px', color: 'var(--text-gray)', lineHeight: 1.5, margin: '0 0 14px' }}>
                  Seus dados são protegidos com criptografia e utilizados unicamente para faturamento
                  fiscal e entrega dos seus pedidos. Você pode solicitar a exclusão da sua conta a qualquer momento.
                </p>
                <button
                  onClick={handleDeleteAccount}
                  style={{
                    padding: '6px 12px',
                    background: '#FEE2E2',
                    color: '#991B1B',
                    border: '1px solid #FCA5A5',
                    borderRadius: '4px',
                    fontWeight: 700,
                    fontSize: '11.5px',
                    cursor: 'pointer'
                  }}
                >
                  Excluir Meus Dados Definitivamente
                </button>
              </div>
            </div>
          ) : (
            /* Formulário de Login / Cadastro */
            <div
              style={{
                background: '#FFFFFF',
                borderRadius: '8px',
                border: '1px solid var(--border-light)',
                padding: '30px',
                boxShadow: 'var(--shadow-card)'
              }}
            >
              <div style={{ display: 'flex', gap: '8px', marginBottom: '20px', borderBottom: '1px solid var(--border-subtle)', paddingBottom: '14px' }}>
                <button
                  onClick={() => setIsRegister(false)}
                  style={{
                    flex: 1,
                    padding: '10px',
                    background: !isRegister ? 'var(--kabum-blue)' : '#F1F5F9',
                    color: !isRegister ? '#FFFFFF' : 'var(--text-dark)',
                    border: 'none',
                    borderRadius: '4px',
                    fontWeight: 800,
                    fontSize: '13px',
                    cursor: 'pointer'
                  }}
                >
                  Já tenho conta
                </button>
                <button
                  onClick={() => setIsRegister(true)}
                  style={{
                    flex: 1,
                    padding: '10px',
                    background: isRegister ? 'var(--kabum-blue)' : '#F1F5F9',
                    color: isRegister ? '#FFFFFF' : 'var(--text-dark)',
                    border: 'none',
                    borderRadius: '4px',
                    fontWeight: 800,
                    fontSize: '13px',
                    cursor: 'pointer'
                  }}
                >
                  Criar Nova Conta
                </button>
              </div>

              {msg && (
                <div style={{ background: '#DCFCE7', color: '#166534', padding: '10px 14px', borderRadius: '4px', marginBottom: '14px', fontSize: '12.5px', fontWeight: 700 }}>
                  {msg}
                </div>
              )}
              {error && (
                <div style={{ background: '#FEE2E2', color: '#991B1B', padding: '10px 14px', borderRadius: '4px', marginBottom: '14px', fontSize: '12.5px', fontWeight: 700 }}>
                  {error}
                </div>
              )}

              {isRegister ? (
                <form onSubmit={handleRegister} style={{ display: 'flex', flexDirection: 'column', gap: '14px' }}>
                  <div>
                    <label style={{ display: 'block', fontSize: '11.5px', fontWeight: 600, color: 'var(--text-gray)', marginBottom: '4px' }}>
                      Nome Completo ou Razão Social *
                    </label>
                    <input
                      type="text"
                      required
                      value={name}
                      onChange={(e) => setName(e.target.value)}
                      placeholder="Nome ou Empresa"
                      style={{ width: '100%', padding: '9px 12px', background: '#FFFFFF', border: '1px solid var(--border-light)', borderRadius: '4px', fontSize: '13px', outline: 'none' }}
                    />
                  </div>
                  <div>
                    <label style={{ display: 'block', fontSize: '11.5px', fontWeight: 600, color: 'var(--text-gray)', marginBottom: '4px' }}>
                      E-mail *
                    </label>
                    <input
                      type="email"
                      required
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      placeholder="seu@email.com.br"
                      style={{ width: '100%', padding: '9px 12px', background: '#FFFFFF', border: '1px solid var(--border-light)', borderRadius: '4px', fontSize: '13px', outline: 'none' }}
                    />
                  </div>
                  <div>
                    <label style={{ display: 'block', fontSize: '11.5px', fontWeight: 600, color: 'var(--text-gray)', marginBottom: '4px' }}>
                      Senha de Acesso *
                    </label>
                    <input
                      type="password"
                      required
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      placeholder="Mínimo 6 caracteres"
                      style={{ width: '100%', padding: '9px 12px', background: '#FFFFFF', border: '1px solid var(--border-light)', borderRadius: '4px', fontSize: '13px', outline: 'none' }}
                    />
                  </div>
                  <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '10px' }}>
                    <div>
                      <label style={{ display: 'block', fontSize: '11.5px', fontWeight: 600, color: 'var(--text-gray)', marginBottom: '4px' }}>
                        CPF ou CNPJ *
                      </label>
                      <input
                        type="text"
                        required
                        value={cpf}
                        onChange={(e) => setCpf(e.target.value)}
                        placeholder="000.000.000-00"
                        style={{ width: '100%', padding: '9px 12px', background: '#FFFFFF', border: '1px solid var(--border-light)', borderRadius: '4px', fontSize: '13px', outline: 'none' }}
                      />
                    </div>
                    <div>
                      <label style={{ display: 'block', fontSize: '11.5px', fontWeight: 600, color: 'var(--text-gray)', marginBottom: '4px' }}>
                        WhatsApp *
                      </label>
                      <input
                        type="tel"
                        required
                        value={phone}
                        onChange={(e) => setPhone(e.target.value)}
                        placeholder="(19) 99999-9999"
                        style={{ width: '100%', padding: '9px 12px', background: '#FFFFFF', border: '1px solid var(--border-light)', borderRadius: '4px', fontSize: '13px', outline: 'none' }}
                      />
                    </div>
                  </div>

                  <label style={{ display: 'flex', alignItems: 'flex-start', gap: '8px', fontSize: '12px', color: 'var(--text-gray)', marginTop: '4px', cursor: 'pointer' }}>
                    <input
                      type="checkbox"
                      required
                      checked={termsAccepted}
                      onChange={(e) => setTermsAccepted(e.target.checked)}
                      style={{ marginTop: '2px', accentColor: 'var(--kabum-orange)' }}
                    />
                    <span>Concordo com os Termos de Uso e Política de Privacidade (LGPD) da BR Distribuidora.</span>
                  </label>

                  <button
                    type="submit"
                    style={{
                      background: 'var(--kabum-orange)',
                      color: '#FFFFFF',
                      border: 'none',
                      padding: '12px',
                      borderRadius: '4px',
                      fontWeight: 800,
                      fontSize: '13px',
                      cursor: 'pointer',
                      marginTop: '6px'
                    }}
                  >
                    Cadastrar e Acessar
                  </button>
                </form>
              ) : (
                <form onSubmit={handleLogin} style={{ display: 'flex', flexDirection: 'column', gap: '14px' }}>
                  <div>
                    <label style={{ display: 'block', fontSize: '11.5px', fontWeight: 600, color: 'var(--text-gray)', marginBottom: '4px' }}>
                      E-mail
                    </label>
                    <input
                      type="email"
                      required
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      placeholder="seu@email.com"
                      style={{ width: '100%', padding: '9px 12px', background: '#FFFFFF', border: '1px solid var(--border-light)', borderRadius: '4px', fontSize: '13px', outline: 'none' }}
                    />
                  </div>
                  <div>
                    <label style={{ display: 'block', fontSize: '11.5px', fontWeight: 600, color: 'var(--text-gray)', marginBottom: '4px' }}>
                      Senha
                    </label>
                    <input
                      type="password"
                      required
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      placeholder="Sua senha"
                      style={{ width: '100%', padding: '9px 12px', background: '#FFFFFF', border: '1px solid var(--border-light)', borderRadius: '4px', fontSize: '13px', outline: 'none' }}
                    />
                  </div>
                  <button
                    type="submit"
                    style={{
                      background: 'var(--kabum-orange)',
                      color: '#FFFFFF',
                      border: 'none',
                      padding: '12px',
                      borderRadius: '4px',
                      fontWeight: 800,
                      fontSize: '13px',
                      cursor: 'pointer',
                      marginTop: '6px'
                    }}
                  >
                    Acessar Minha Conta
                  </button>
                </form>
              )}
            </div>
          )}
        </div>
      </main>

      <Footer />
      <BRBot />
    </>
  );
}
