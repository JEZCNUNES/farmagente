import React, { useState } from 'react';
import '../css/styles.css';
import FarmaBot from '../components/FarmaBot';
import CartDrawer from '../components/CartDrawer';

export default function MyApp({ Component, pageProps }) {
  const [cartOpen, setCartOpen] = useState(false);

  return (
    <>
      <Component {...pageProps} onOpenCart={() => setCartOpen(true)} />
      <FarmaBot />
      <CartDrawer isOpen={cartOpen} onClose={() => setCartOpen(false)} />
    </>
  );
}
